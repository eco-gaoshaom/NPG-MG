library(dplyr)
library(ggplot2)
library(ggbreak)

site_mro_mip <- read.table('../fig.2/site.rand_mro_mip_div',header = T)

meta_data <- read.delim('../fig.2/841sample.metadata',header = T)
new_data <- meta_data[meta_data$Mapping_rate>=50 & meta_data$Richness > 10,]

rownames(site_mro_mip) <- new_data$Sample_name

pri_data <- data.frame(site_mro_mip,new_data)
pri_data <- pri_data %>%  mutate(mro_new = if_else(mro > rad_mro + rad_mro_ci, mro, -mro)) 
pri_data <- pri_data %>%  mutate(mip_new = if_else(mip > rad_mip + rad_mip_ci, mip, -mip)) 
pri_data$intertype <- ifelse(pri_data$mro_new > 0 & pri_data$mip_new > 0, "Type 1",ifelse(pri_data$mro_new < 0 & pri_data$mip_new > 0, "Type 2",ifelse(pri_data$mro_new < 0 & pri_data$mip_new < 0, "Type 3","Type 4")))

#clade_type <- aggregate(pri_data$intertype,list(pri_data$group,pri_data$intertype),length)
spe_type <- aggregate(pri_data$intertype,list(pri_data$Primate_species,pri_data$intertype),length)

spe_sum <- spe_type %>%  
  group_by(Group.1) %>%  
  summarise(total_x = sum(x), .groups = 'drop')  

spe_type <- spe_type %>%  
  left_join(spe_sum, by = 'Group.1') %>%  
  mutate(proportion = x * 100/ total_x)  

ggplot(spe_type,aes(Group.1,proportion,fill=Group.2))+
  geom_bar(stat = 'identity',position = 'stack',width =0.25)+
  scale_fill_manual(values = c("#bc587d","#90bb97","#ab84b6","#3ca6cc"))+
  theme_bw()+coord_flip()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=12),axis.title.y = element_text(size=8),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=8,colour = 'black',angle = 0,hjust = 1),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=3),
        legend.position = 'top')+
  labs(x="Species",y="Proportion of interactive types")+
  #scale_x_continuous(limits = c(0.45,0.6),breaks=seq(0.45,0.6,0.05))+
  scale_y_continuous(limits = c(0,100),breaks=seq(0,100,25))+
  expand_limits(y=0)
