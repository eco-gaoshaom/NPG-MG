library(ape)
library(geiger)
library(treeplyr)
library(phytools)
library(caper)
library(TreeTools)
library(phangorn)
library(reshape2)
library(phylosignal)
library(phylobase)
library(vegan)
library(tidyverse)
library(geiger)
library(MCMCglmm)
library(coda)
library(ggplot2)

pri_data <- read.table('../fig.2/site.rand_mro_mip_div',header = T)

new_trees_trim <- list()

for (i in 1:100){
  name <- paste("../fig.2/new_trees_trim",i)
  new_trees_trim[[i]] <- read.newick(name)
}

#MCMCglmm

pri_data$phylo <- pri_data$Alternative_Species

scale_data <- decostand(apply(pri_data[,c("X001aai","X001div","equator")],2,as.numeric),method = 'standardize')
pri_mcmc <- data.frame(scale_data,pri_data[,c("Env_group","Diet","Alternative_Species","Country")])


new_trees_trim2 <- list()
for (i in 1:100){
  new_trees_trim2[[i]] <- make.treedata(tree = new_trees_trim[[i]],
                                        data = pri_mcmc, 
                                        name_column = "Alternative_Species")$phy
}


model_mcmcglmm_X001aai <- list()
X001aai_mcmc <- matrix(0,800,3)
for (i in 1:100){
  print(i)
  tree_mcc_trim <- di2multi(new_trees_trim2[[i]])
  tree_mcc_trim$node.label <- NULL
  inv.phylo <- inverseA(tree_mcc_trim, nodes = "TIPS", scale = TRUE)$Ainv
  prior <- list(G = list(
    G1 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000),
    G2 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000)),
    R = list(V = 1, nu = 0.002))
  model_mcmcglmm <- MCMCglmm(X001aai ~  Diet + Env_group + equator + Gut_morphology, 
                             data = pri_mcmc, 
                             random = ~ Alternative_Species + Country,
                             ginverse = list(Alternative_Species = inv.phylo), 
                             prior = prior,
                             family = "gaussian",
                             nitt = 160000, thin = 30, burnin = 10000,
                             verbose = FALSE)
  sum <- summary(model_mcmcglmm)
  lambda <- model_mcmcglmm$VCV[,'Alternative_Species']/(model_mcmcglmm$VCV[,'Alternative_Species'] + model_mcmcglmm$VCV[,'units'])
  X001aai_mcmc[i,] <- as.numeric(sum$solutions[1,1:3])
  X001aai_mcmc[100+i,] <- as.numeric(sum$solutions[2,1:3])
  X001aai_mcmc[200+i,] <- as.numeric(sum$solutions[3,1:3])
  X001aai_mcmc[300+i,] <- as.numeric(sum$solutions[4,1:3])
  X001aai_mcmc[400+i,] <- as.numeric(sum$solutions[5,1:3])
  X001aai_mcmc[500+i,] <- as.numeric(sum$solutions[6,1:3])
  X001aai_mcmc[600+i,] <- as.numeric(sum$solutions[7,1:3])
  X001aai_mcmc[700+i,] <- as.numeric(c(mean(lambda),HPDinterval(lambda)[1],HPDinterval(lambda)[2]))
  model_mcmcglmm_X001aai[[i]] <- model_mcmcglmm
}

model_mcmcglmm_X001div <- list()
X001div_mcmc <- matrix(0,800,3)
for (i in 1:100){
  print(i)
  tree_mcc_trim <- di2multi(new_trees_trim2[[i]])
  tree_mcc_trim$node.label <- NULL
  inv.phylo <- inverseA(tree_mcc_trim, nodes = "TIPS", scale = TRUE)$Ainv
  prior <- list(G = list(
    G1 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000),
    G2 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000)),
    R = list(V = 1, nu = 0.002))
  model_mcmcglmm <- MCMCglmm(X001div ~  Diet + Env_group + equator + Gut_morphology, 
                             data = pri_mcmc, 
                             random = ~ Alternative_Species + Country,
                             ginverse = list(Alternative_Species = inv.phylo), 
                             prior = prior,
                             family = "gaussian",
                             nitt = 160000, thin = 30, burnin = 10000,
                             verbose = FALSE)
  sum <- summary(model_mcmcglmm)
  lambda <- model_mcmcglmm$VCV[,'Alternative_Species']/(model_mcmcglmm$VCV[,'Alternative_Species'] + model_mcmcglmm$VCV[,'units'])
  X001div_mcmc[i,] <- as.numeric(sum$solutions[1,1:3])
  X001div_mcmc[100+i,] <- as.numeric(sum$solutions[2,1:3])
  X001div_mcmc[200+i,] <- as.numeric(sum$solutions[3,1:3])
  X001div_mcmc[300+i,] <- as.numeric(sum$solutions[4,1:3])
  X001div_mcmc[400+i,] <- as.numeric(sum$solutions[5,1:3])
  X001div_mcmc[500+i,] <- as.numeric(sum$solutions[6,1:3])
  X001div_mcmc[600+i,] <- as.numeric(sum$solutions[7,1:3])
  X001div_mcmc[700+i,] <- as.numeric(c(mean(lambda),HPDinterval(lambda)[1],HPDinterval(lambda)[2]))
  model_mcmcglmm_X001div[[i]] <- model_mcmcglmm
}

colnames(X001aai_mcmc) <- colnames(X001div_mcmc) <- c("post_mean","lower_CI","upper_CI")

factor_g <- as.character(c(replicate(100,"Intercept"),replicate(100,"Fru2Fol"),replicate(100,"Her2Fol"),replicate(100,"Omn2Fol"),
                           replicate(100,"Wild2Cap"),replicate(100,"Dist."),replicate(100,"Hind2Foregut"),replicate(100,"Phylogeny")))

X001aai_effects <- data.frame(as.data.frame(X001aai_mcmc),factor_g)
X001div_effects <- data.frame(as.data.frame(X001div_mcmc),factor_g)

X001aai_effects <- aggregate(X001aai_effects[,1:3],list(factor_g),mean)
X001div_effects <- aggregate(X001div_effects[,1:3],list(factor_g),mean)

effects_df <- rbind(X001aai_effects,X001div_effects)
effects_df$var_g <- as.character(c(replicate(8,"X001aai"),replicate(8,"X001div")))
effects_df$num <- c(13,3,5,11,1,7,15,9,14,4,6,12,2,8,16,10)
effects_df <- effects_df[order(effects_df$num,decreasing = F),]
write.table(effects_df,"mcmcglmm_X001aaiX001div.effects_df",sep = "\t")

ggplot(effects_df)+
  geom_point(aes(num,post_mean,color = var_g),size = 3,shape  = 16,alpha = 1)+
  geom_segment(aes(x = num,xend = num,y = lower_CI, yend = upper_CI))+
  geom_segment(aes(x = num-0.1,y = lower_CI,xend = num+0.1,yend=lower_CI))+
  geom_segment(aes(x = num-0.1,y = upper_CI,xend = num+0.1,yend=upper_CI))+
  scale_fill_manual(values=c("#bc587d","#3ca6cc"))+
  theme_classic(base_line_size = 1)+
  labs(x="Factors",y="Effect on X001aai/X001div")+theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 1,angle = 0,size=10,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  coord_flip()+
  geom_hline(yintercept=0,linetype=4,color="grey",linewidth=0.5)+
  expand_limits(x=c(1,16))+
  scale_x_continuous(breaks = seq(1,16,1),labels = 
                       (c("Intercept","Intercept","Frugivore vs. Folivore","Frugivore vs. Folivore",
                          "Herbivore vs. Folivore","Herbivore vs. Folivore", "Omnivore vs. Folivore","Omnivore vs. Folivore",
                          "Wild vs. Captive","Wild vs. Captive","Hindgut vs. Foregut","Hindgut vs. Foregut",
                          "Distance to equator","Distance to equator","Phylogeny","Phylogeny")))+
  expand_limits(y=c(-16,16))+
  scale_y_continuous(limits = c(-16,16),breaks = seq(-16,16,8))


model_mcmcglmm_mcmc_X001aai <- list()
model_mcmcglmm_mcmc_X001div <- list()
for (i in 1:100){
  model_mcmcglmm_mcmc_X001aai[[i]] <- as.mcmc(model_mcmcglmm_X001aai[[i]]$Sol)
  model_mcmcglmm_mcmc_X001div[[i]] <- as.mcmc(model_mcmcglmm_X001div[[i]]$Sol)
}
zz_X001aai <- mcmc.list(model_mcmcglmm_mcmc_X001aai)
zz_X001div <- mcmc.list(model_mcmcglmm_mcmc_X001div)
zzplot_X001aai <- gelman.plot(zz_X001aai)
zzplot_X001div <- gelman.plot(zz_X001div)

save.image("mcmcglmm_X001aaiX001div.RData")


zz_group <- c(zzplot_X001aai$last.iter)

zz_X001aai_int <- melt(data.frame(zzplot_X001aai$shrink[,1,],zz_group),id.vars = c("zz_group"))
zz_X001aai_fru <- melt(data.frame(zzplot_X001aai$shrink[,2,],zz_group),id.vars = c("zz_group"))
zz_X001aai_her <- melt(data.frame(zzplot_X001aai$shrink[,3,],zz_group),id.vars = c("zz_group"))
zz_X001aai_omn <- melt(data.frame(zzplot_X001aai$shrink[,4,],zz_group),id.vars = c("zz_group"))
zz_X001aai_wild <- melt(data.frame(zzplot_X001aai$shrink[,5,],zz_group),id.vars = c("zz_group"))
zz_X001aai_dist <- melt(data.frame(zzplot_X001aai$shrink[,6,],zz_group),id.vars = c("zz_group"))
zz_X001aai_hindgut <- melt(data.frame(zzplot_X001aai$shrink[,7,],zz_group),id.vars = c("zz_group"))


p15 <- ggplot(zz_X001aai_int)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p15

p16 <- ggplot(zz_X001aai_fru)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p16

p17 <- ggplot(zz_X001aai_her)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p17

p18 <- ggplot(zz_X001aai_omn)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p18

p19 <- ggplot(zz_X001aai_wild)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p19

p20 <- ggplot(zz_X001aai_dist)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p20

p21 <- ggplot(zz_X001aai_hindgut)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p21

zz_X001div_int <- melt(data.frame(zzplot_X001div$shrink[,1,],zz_group),id.vars = c("zz_group"))
zz_X001div_fru <- melt(data.frame(zzplot_X001div$shrink[,2,],zz_group),id.vars = c("zz_group"))
zz_X001div_her <- melt(data.frame(zzplot_X001div$shrink[,3,],zz_group),id.vars = c("zz_group"))
zz_X001div_omn <- melt(data.frame(zzplot_X001div$shrink[,4,],zz_group),id.vars = c("zz_group"))
zz_X001div_wild <- melt(data.frame(zzplot_X001div$shrink[,5,],zz_group),id.vars = c("zz_group"))
zz_X001div_dist <- melt(data.frame(zzplot_X001div$shrink[,6,],zz_group),id.vars = c("zz_group"))
zz_X001div_hindgut <- melt(data.frame(zzplot_X001div$shrink[,7,],zz_group),id.vars = c("zz_group"))


p22 <- ggplot(zz_X001div_int)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p22

p23 <- ggplot(zz_X001div_fru)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p23

p24 <- ggplot(zz_X001div_her)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p24

p25 <- ggplot(zz_X001div_omn)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p25

p26 <- ggplot(zz_X001div_wild)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p26

p27 <- ggplot(zz_X001div_dist)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p27

p28 <- ggplot(zz_X001div_hindgut)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p28


library(gridExtra)
plots <- list(p1,p8,p15,p22,
              p2,p9,p16,p23,
              p3,p10,p17,p24,
              p4,p11,p18,p25,
              p5,p12,p19,p26,
              p6,p13,p20,p27,
              p7,p14,p21,p28)
grid.arrange(grobs = plots,ncol=4)
