library(ggplot2)
library(data.table)
library(ggsignif)
pri_data <- read.table('site.rand_mro_mip_div',header = T)
pri_data$Primate_group <- factor(pri_data$Primate_group,levels = c("Ape","Lemur","Monkey"))

range(pri_data$mro)
range(pri_data$mip)

#geom point for all samples
ggplot(pri_data)+
  geom_point(aes(mro,mip,color = Primate_group),shape=17,size = 3)+
  scale_color_manual(values=c("#bc587d","#ab84b6","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  labs(x="Competition (MRO score)",y="Cooperation (MIP score)")+
  scale_x_continuous(limits = c(0.53,0.65),breaks=seq(0.53,0.65,0.04))+
  scale_y_continuous(limits = c(10,100),breaks=seq(10,100,30))+
  coord_cartesian(xlim= c(0.53,0.65),ylim = c(10,100))+
  expand_limits(x=0.53,y=10)

p1 <- ggplot(pri_data)+
  geom_point(aes(X001aai,mro),size=1.5,color="#3ca6cc")+
  geom_smooth(aes(X001aai,mro),method='lm',fill=NA,color = "#90bb97")+
  labs(x="Mean AAI (%)",y="Competition (MRO)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'bottom')+
  expand_limits(y=0.5,x=37)+
  scale_x_continuous(limits = c(37,47),breaks = seq(37,47,2.5))+
  scale_y_continuous(limits = c(0.5,0.7),breaks=seq(0.5,0.7,0.05)) 
p1

p2 <- ggplot(pri_data)+
  geom_point(aes(X001div,mip),size=1.5,color="#bc587d")+
  geom_smooth(aes(X001div,mip),method='lm',fill=NA,color = "#90bb97")+
  labs(x="Richness",y="Cooperation (MIP)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'bottom')+
  expand_limits(x=0,y=10)+
  scale_x_continuous(limits = c(0,180),breaks = seq(0,180,90))+
  scale_y_continuous(limits = c(10,120),breaks=seq(10,110,25))
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=2)


pri_data_t1 <- pri_data[pri_data$intertype == "Type 1",]
pri_data_t2 <- pri_data[pri_data$intertype == "Type 2",]
pri_data_t3 <- pri_data[pri_data$intertype == "Type 3",]
pri_data_t4 <- pri_data[pri_data$intertype == "Type 4",]

range(pri_data_t1$mro)
range(pri_data_t2$mro) 
range(pri_data_t3$mro)
range(pri_data_t4$mro)

range(pri_data_t1$mip)
range(pri_data_t2$mip) 
range(pri_data_t3$mip)
range(pri_data_t4$mip)

#geom_point for type1
p1 <- ggplot(pri_data_t1,aes(mro,mip))+
  geom_point(size=3,shape=17,aes(color = Primate_group),alpha = 1)+
  #scale_shape_manual(values = c(1,2,16,17))+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  labs(x="Competition (MRO score)",y="Cooperation (MIP score)")+
  scale_x_continuous(limits = c(0.53,0.65),breaks=seq(0.53,0.65,0.04))+
  scale_y_continuous(limits = c(10,100),breaks=seq(10,100,30))+
  coord_cartesian(xlim= c(0.53,0.65),ylim = c(10,100))+
  expand_limits(x=0.53,y=10)
p1

p2 <- ggplot(pri_data_t2,aes(mro,mip))+
  geom_point(size=3,shape=17,aes(color = Primate_group),alpha = 1)+
  #scale_shape_manual(values = c(1,2,16,17))+
  scale_color_manual(values=c("#bc587d","#ab84b6","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  labs(x="Competition (MRO score)",y="Cooperation (MIP score)")+
  scale_x_continuous(limits = c(0.53,0.56),breaks=seq(0.53,0.56,0.01))+
  scale_y_continuous(limits = c(10,100),breaks=seq(10,100,30))+
  coord_cartesian(xlim= c(0.53,0.56),ylim = c(10,100))+
  expand_limits(x=0.53,y=10)
p2

p3 <- ggplot(pri_data_t3,aes(mro,mip))+
  geom_point(size=3,shape=17,aes(color = Primate_group),alpha = 1)+
  #scale_shape_manual(values = c(1,2,16,17))+
  scale_color_manual(values=c("#bc587d","#ab84b6","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  labs(x="Competition (MRO score)",y="Cooperation (MIP score)")+
  scale_x_continuous(limits = c(0.53,0.56),breaks=seq(0.53,0.56,0.01))+
  scale_y_continuous(limits = c(35,95),breaks=seq(35,95,20))+
  coord_cartesian(xlim= c(0.53,0.56),ylim = c(35,95))+
  expand_limits(x=0.53,y=35)
p3

p4 <- ggplot(pri_data_t4,aes(mro,mip))+
  geom_point(size=3,shape=17,aes(color = Primate_group),alpha = 1)+
  #scale_shape_manual(values = c(1,2,16,17))+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  labs(x="Competition (MRO score)",y="Cooperation (MIP score)")+
  scale_x_continuous(limits = c(0.53,0.65),breaks=seq(0.53,0.65,0.04))+
  scale_y_continuous(limits = c(10,100),breaks=seq(10,100,30))+
  coord_cartesian(xlim= c(0.53,0.65),ylim = c(10,100))+
  expand_limits(x=0.53,y=10)
p4

library(gridExtra)
plots <- list(p1,p2,p3,p4)
grid.arrange(grobs = plots,ncol=4)
