library(ape)
library(geiger)
library(treeplyr)
library(phytools)
library(caper)
library(TreeTools)
library(phangorn)
library(reshape2)
library(phylosignal)
library(phylobase)
library(vegan)
library(tidyverse)
library(geiger)
library(MCMCglmm)
library(coda)
library(ggplot2)

pri_data <- read.table('site.rand_mro_mip_div',header = T)

new_trees_trim <- list()
for (i in 1:100){
  name <- paste("new_trees_trim",i)
  new_trees_trim[[i]] <- read.newick(name)
}

#MCMCglmm

pri_data$phylo <- pri_data$Alternative_Species

scale_data <- decostand(apply(pri_data[,c("mro","mip","equator")],2,as.numeric),method = 'standardize')
pri_mcmc <- data.frame(scale_data,pri_data[,c("Env_group","Diet","Gut_morphology","Alternative_Species","Country")])


new_trees_trim2 <- list()
for (i in 1:100){
  new_trees_trim2[[i]] <- make.treedata(tree = new_trees_trim[[i]],
                                        data = pri_mcmc, 
                                        name_column = "Alternative_Species")$phy
}

tree_mcc_trim <- di2multi(new_trees_trim2[[1]])
tree_mcc_trim$node.label <- NULL
inv.phylo <- inverseA(tree_mcc_trim, nodes = "TIPS", scale = TRUE)$Ainv
prior <- list(G = list(
  G1 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000),
  G2 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000)),
  R = list(V = 1, nu = 0.002))
model_mcmcglmm_mro <- MCMCglmm(mro ~  Diet + Env_group + equator + Gut_morphology, 
                           data = pri_data, 
                           random = ~ Alternative_Species + Country,
                           ginverse = list(Alternative_Species = inv.phylo), 
                           prior = prior,
                           family = "gaussian",
                           nitt = 160000, thin = 60, burnin = 10000,
                           verbose = FALSE)
sum <- summary(model_mcmcglmm_mro)
sum$solutions[,1:3]
lamba <- model_mcmcglmm_mro$VCV[,'Alternative_Species']/(model_mcmcglmm_mro$VCV[,'Alternative_Species'] + model_mcmcglmm_mro$VCV[,'units'])
c(mean(lamba),HPDinterval(lamba)[1],HPDinterval(lamba)[2])

model_mcmcglmm_mip <- MCMCglmm(mip ~  Diet + Env_group + equator + Gut_morphology, 
                           data = pri_mcmc, 
                           random = ~ Alternative_Species + Country,
                           ginverse = list(Alternative_Species = inv.phylo), 
                           prior = prior,
                           family = "gaussian",
                           nitt = 160000, thin = 30, burnin = 10000,
                           verbose = FALSE)
sum <- summary(model_mcmcglmm_mip)
sum$Gcovariances[1,1:3]
sum$solutions[,1:3]
lambda <- model_mcmcglmm_mip$VCV[,'Alternative_Species']/(model_mcmcglmm_mip$VCV[,'Alternative_Species'] + model_mcmcglmm_mip$VCV[,'units'])
c(mean(lamba),HPDinterval(lamba)[1],HPDinterval(lamba)[2])

model_mcmcglmm_mro <- list()
mro_mcmc <- matrix(0,800,3)
for (i in 1:100){
  print(i)
  tree_mcc_trim <- di2multi(new_trees_trim2[[i]])
  tree_mcc_trim$node.label <- NULL
  inv.phylo <- inverseA(tree_mcc_trim, nodes = "TIPS", scale = TRUE)$Ainv
  prior <- list(G = list(
    G1 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000),
    G2 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000)),
    R = list(V = 1, nu = 0.002))
  model_mcmcglmm <- MCMCglmm(mro ~  Diet + Env_group + equator + Gut_morphology, 
                             data = pri_mcmc, 
                             random = ~ Alternative_Species + Country,
                             ginverse = list(Alternative_Species = inv.phylo), 
                             prior = prior,
                             family = "gaussian",
                             nitt = 160000, thin = 30, burnin = 10000,
                             verbose = FALSE)
  sum <- summary(model_mcmcglmm)
  lambda <- model_mcmcglmm$VCV[,'Alternative_Species']/(model_mcmcglmm$VCV[,'Alternative_Species'] + model_mcmcglmm$VCV[,'units'])
  mro_mcmc[i,] <- as.numeric(sum$solutions[1,1:3])
  mro_mcmc[100+i,] <- as.numeric(sum$solutions[2,1:3])
  mro_mcmc[200+i,] <- as.numeric(sum$solutions[3,1:3])
  mro_mcmc[300+i,] <- as.numeric(sum$solutions[4,1:3])
  mro_mcmc[400+i,] <- as.numeric(sum$solutions[5,1:3])
  mro_mcmc[500+i,] <- as.numeric(sum$solutions[6,1:3])
  mro_mcmc[600+i,] <- as.numeric(sum$solutions[7,1:3])
  mro_mcmc[700+i,] <- as.numeric(c(mean(lambda),HPDinterval(lambda)[1],HPDinterval(lambda)[2]))
  model_mcmcglmm_mro[[i]] <- model_mcmcglmm
}

model_mcmcglmm_mip <- list()
mip_mcmc <- matrix(0,800,3)
for (i in 1:100){
  print(i)
  tree_mcc_trim <- di2multi(new_trees_trim2[[i]])
  tree_mcc_trim$node.label <- NULL
  inv.phylo <- inverseA(tree_mcc_trim, nodes = "TIPS", scale = TRUE)$Ainv
  prior <- list(G = list(
    G1 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000),
    G2 = list(V = 1, nu = 1,alpha.mu = 0,alpha.V = 1000)),
    R = list(V = 1, nu = 0.002))
  model_mcmcglmm <- MCMCglmm(mip ~  Diet + Env_group + equator + Gut_morphology, 
                             data = pri_mcmc, 
                             random = ~ Alternative_Species + Country,
                             ginverse = list(Alternative_Species = inv.phylo), 
                             prior = prior,
                             family = "gaussian",
                             nitt = 160000, thin = 30, burnin = 10000,
                             verbose = FALSE)
  sum <- summary(model_mcmcglmm)
  lambda <- model_mcmcglmm$VCV[,'Alternative_Species']/(model_mcmcglmm$VCV[,'Alternative_Species'] + model_mcmcglmm$VCV[,'units'])
  mip_mcmc[i,] <- as.numeric(sum$solutions[1,1:3])
  mip_mcmc[100+i,] <- as.numeric(sum$solutions[2,1:3])
  mip_mcmc[200+i,] <- as.numeric(sum$solutions[3,1:3])
  mip_mcmc[300+i,] <- as.numeric(sum$solutions[4,1:3])
  mip_mcmc[400+i,] <- as.numeric(sum$solutions[5,1:3])
  mip_mcmc[500+i,] <- as.numeric(sum$solutions[6,1:3])
  mip_mcmc[600+i,] <- as.numeric(sum$solutions[7,1:3])
  mip_mcmc[700+i,] <- as.numeric(c(mean(lambda),HPDinterval(lambda)[1],HPDinterval(lambda)[2]))
  model_mcmcglmm_mip[[i]] <- model_mcmcglmm
}

colnames(mro_mcmc) <- colnames(mip_mcmc) <- c("post_mean","lower_CI","upper_CI")

factor_g <- as.character(c(replicate(100,"Intercept"),replicate(100,"Fru2Fol"),replicate(100,"Her2Fol"),replicate(100,"Omn2Fol"),
                           replicate(100,"Wild2Cap"),replicate(100,"Dist."),replicate(100,"Hind2Foregut"),replicate(100,"Phylogeny")))

mro_effects <- data.frame(as.data.frame(mro_mcmc),factor_g)
mip_effects <- data.frame(as.data.frame(mip_mcmc),factor_g)

mro_effects <- aggregate(mro_effects[,1:3],list(factor_g),mean)
mip_effects <- aggregate(mip_effects[,1:3],list(factor_g),mean)

effects_df <- rbind(mro_effects,mip_effects)
effects_df$var_g <- as.character(c(replicate(8,"mro"),replicate(8,"mip")))
effects_df$num <- c(13,3,5,11,1,7,15,9,14,4,6,12,2,8,16,10)
effects_df <- effects_df[order(effects_df$num,decreasing = F),]
write.table(effects_df,"mcmcglmm_mromip.effects_df",sep = "\t")

ggplot(effects_df)+
  geom_point(aes(num,post_mean,color = var_g),size = 3,shape  = 16,alpha = 1)+
  geom_segment(aes(x = num,xend = num,y = lower_CI, yend = upper_CI))+
  geom_segment(aes(x = num-0.05,y = lower_CI,xend = num+0.05,yend=lower_CI))+
  geom_segment(aes(x = num-0.05,y = upper_CI,xend = num+0.05,yend=upper_CI))+
  scale_fill_manual(values=c("#bc587d","#3ca6cc"))+
  theme_classic(base_line_size = 1)+
  labs(x="Factors",y="Effect on MRO/MIP")+theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 1,angle = 45,size=10,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  geom_hline(yintercept=0,linetype=4,color="grey",linewidth=0.5)+
  expand_limits(x=c(1,16))+
  scale_x_continuous(breaks = seq(1,16,1),labels = 
                       (c("Intercept","Intercept","Frugivore vs. Folivore","Frugivore vs. Folivore",
                          "Herbivore vs. Folivore","Herbivore vs. Folivore", "Omnivore vs. Folivore","Omnivore vs. Folivore",
                          "Wild vs. Captive","Wild vs. Captive","Foregut vs. Hindgut","Foregut vs. Hindgut",
                          "Distance to equator","Distance to equator","Phylogeny","Phylogeny")))+
  expand_limits(y=c(-8,8))+scale_y_continuous(limits = c(-8,8),breaks = seq(-8,8,4))


model_mcmcglmm_mcmc_mro <- list()
model_mcmcglmm_mcmc_mip <- list()
for (i in 1:100){
  model_mcmcglmm_mcmc_mro[[i]] <- as.mcmc(model_mcmcglmm_mro[[i]]$Sol)
  model_mcmcglmm_mcmc_mip[[i]] <- as.mcmc(model_mcmcglmm_mip[[i]]$Sol)
}
zz_mro <- mcmc.list(model_mcmcglmm_mcmc_mro)
zz_mip <- mcmc.list(model_mcmcglmm_mcmc_mip)
zzplot_mro <- gelman.plot(zz_mro)
zzplot_mip <- gelman.plot(zz_mip)


zz_group <- c(zzplot_mro$last.iter)

zz_mro_int <- melt(data.frame(zzplot_mro$shrink[,1,],zz_group),id.vars = c("zz_group"))
zz_mro_fru <- melt(data.frame(zzplot_mro$shrink[,2,],zz_group),id.vars = c("zz_group"))
zz_mro_her <- melt(data.frame(zzplot_mro$shrink[,3,],zz_group),id.vars = c("zz_group"))
zz_mro_omn <- melt(data.frame(zzplot_mro$shrink[,4,],zz_group),id.vars = c("zz_group"))
zz_mro_wild <- melt(data.frame(zzplot_mro$shrink[,5,],zz_group),id.vars = c("zz_group"))
zz_mro_dist <- melt(data.frame(zzplot_mro$shrink[,6,],zz_group),id.vars = c("zz_group"))
zz_mro_hindgut <- melt(data.frame(zzplot_mro$shrink[,7,],zz_group),id.vars = c("zz_group"))


p1 <- ggplot(zz_mro_int)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p1

p2 <- ggplot(zz_mro_fru)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p2

p3 <- ggplot(zz_mro_her)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p3

p4 <- ggplot(zz_mro_omn)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p4

p5 <- ggplot(zz_mro_wild)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p5

p6 <- ggplot(zz_mro_dist)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p6

p7 <- ggplot(zz_mro_hindgut)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p7

zz_mip_int <- melt(data.frame(zzplot_mip$shrink[,1,],zz_group),id.vars = c("zz_group"))
zz_mip_fru <- melt(data.frame(zzplot_mip$shrink[,2,],zz_group),id.vars = c("zz_group"))
zz_mip_her <- melt(data.frame(zzplot_mip$shrink[,3,],zz_group),id.vars = c("zz_group"))
zz_mip_omn <- melt(data.frame(zzplot_mip$shrink[,4,],zz_group),id.vars = c("zz_group"))
zz_mip_wild <- melt(data.frame(zzplot_mip$shrink[,5,],zz_group),id.vars = c("zz_group"))
zz_mip_dist <- melt(data.frame(zzplot_mip$shrink[,6,],zz_group),id.vars = c("zz_group"))
zz_mip_hindgut <- melt(data.frame(zzplot_mip$shrink[,7,],zz_group),id.vars = c("zz_group"))


p8 <- ggplot(zz_mip_int)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p8

p9 <- ggplot(zz_mip_fru)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p9

p10 <- ggplot(zz_mip_her)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p10

p11 <- ggplot(zz_mip_omn)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p11

p12 <- ggplot(zz_mip_wild)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p12

p13 <- ggplot(zz_mip_dist)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p13

p14 <- ggplot(zz_mip_hindgut)+
  labs(x="Last iteration in chain",y='Scale reduction factor')+
  #geom_point(aes(zz_group,value),size=2,shape=16,color=rgb(255,59,59,max=255))+
  geom_line(aes(zz_group,value,color = variable,linetype = variable))+
  scale_color_manual(values = c("black","red"))+
  scale_linetype_manual(values = c("solid","dashed"))+
  geom_hline(yintercept=1,linetype=4,color="grey",linewidth=1)+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_x_continuous(breaks = seq(10000,160000,50000))+
  scale_y_continuous(breaks = seq(1,1.01,0.005))+theme(legend.position = 'none')+
  coord_cartesian(ylim = c(1,1.01))
p14


