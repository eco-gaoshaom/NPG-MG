#we firstly plot boxplot for mro/mip across different diet/habitat/primate groups
library(ggplot2)
library(data.table)
library(ggsignif)
library(dplyr)
pri_data <- read.table('site.rand_mro_mip_div',header = T)

pairwise.wilcox.test(pri_data$mro,pri_data$Primate_group,p.adjust.method = 'BH')
wilcox.test(pri_data$mro~pri_data$Env_group)
wilcox.test(pri_data$mro~pri_data$Gut_morphology)
pairwise.wilcox.test(pri_data$mro,pri_data$Diet,p.adjust.method = 'BH')

pairwise.wilcox.test(pri_data$mip,pri_data$Primate_group,p.adjust.method = 'BH')
wilcox.test(pri_data$mip~pri_data$Env_group)
wilcox.test(pri_data$mip~pri_data$Gut_morphology)
pairwise.wilcox.test(pri_data$mip,pri_data$Diet,p.adjust.method = 'BH')

p1 <- ggplot(pri_data,aes(Diet,mro))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Diet),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Diet),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#90bb97","#3ca6cc","#ab84b6"))+
  geom_signif(comparisons = list(c("Frugivore","Folivore"),
                                 c("Frugivore","Herbivore"),
                                 c("Frugivore","Omnivore"),
                                 c("Folivore","Herbivore"),
                                 c("Folivore","Omnivore"),
                                 c("Herbivore","Omnivore")),
              map_signif_level = F, 
              textsize = 4, 
              step_increase = 0.15,
              test = "wilcox.test")+
  labs(x = "Diet group",y="Competition (MRO score)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.52,0.76),breaks = seq(0.52,0.76,0.04))+
  coord_cartesian(ylim= c(0.52,0.76))+
  expand_limits(y=0.52)  
p1

p2 <- ggplot(pri_data,aes(Env_group,mro))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Env_group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Env_group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Habitat group",y="Competition (MRO score)")+
  geom_signif(comparisons = list(c("Wild","Captive")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.52,0.76),breaks = seq(0.52,0.76,0.04))+
  coord_cartesian(ylim= c(0.52,0.76))+
  expand_limits(y=0.52) 
p2

p3 <- ggplot(pri_data,aes(Gut_morphology,mro))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Gut_morphology),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Gut_morphology),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Gut morphology",y="Competition (MRO score)")+
  geom_signif(comparisons = list(c("Hindgut","Foregut")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.52,0.76),breaks = seq(0.52,0.76,0.04))+
  coord_cartesian(ylim= c(0.52,0.76))+
  expand_limits(y=0.52) 
p3

p4 <- ggplot(pri_data,aes(Primate_group,mro))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Primate_group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Primate_group),width=0.35,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc","#ab84b6"))+
  labs(x = "Phylogenetic group",y="Competition (MRO score)")+
  geom_signif(comparisons = list(c("Ape","Lemur"),c("Lemur","Monkey"),c("Ape","Monkey")),
              map_signif_level = F, 
              textsize = 4, 
              step_increase = 0.2,
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
  legend.position = 'none')+
  scale_y_continuous(limits = c(0.52,0.76),breaks = seq(0.52,0.76,0.04))+
  coord_cartesian(ylim= c(0.52,0.76))+
  expand_limits(y=0.52) 
p4


p5 <- ggplot(pri_data,aes(Diet,mip))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Diet),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Diet),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#90bb97","#3ca6cc","#ab84b6"))+
  geom_signif(comparisons = list(c("Frugivore","Folivore"),
                                 c("Frugivore","Herbivore"),
                                 c("Frugivore","Omnivore"),
                                 c("Folivore","Herbivore"),
                                 c("Folivore","Omnivore"),
                                 c("Herbivore","Omnivore")),
              map_signif_level = F, 
              textsize = 4, 
              step_increase = 0.1,
              test = "wilcox.test")+
  labs(x = "Diet group",y="Cooperation (MIP score)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(10,160),breaks = seq(10,160,50))+
  coord_cartesian(ylim= c(10,160))+
  expand_limits(y=10)  
p5

p6 <- ggplot(pri_data,aes(Env_group,mip))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Env_group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Env_group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  geom_signif(comparisons = list(c("Wild","Captive")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  labs(x = "Habitat group",y="Cooperation (MIP score)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(10,160),breaks = seq(10,160,50))+
  coord_cartesian(ylim= c(10,160))+
  expand_limits(y=10) 
p6

p7 <- ggplot(pri_data,aes(Gut_morphology,mip))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Gut_morphology),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Gut_morphology),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Gut morphology",y="Cooperation (MIP score)")+
  geom_signif(comparisons = list(c("Hindgut","Foregut")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(10,160),breaks = seq(10,160,50))+
  coord_cartesian(ylim= c(10,160))+
  expand_limits(y=10) 
p7

p8 <- ggplot(pri_data,aes(Primate_group,mip))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = Primate_group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = Primate_group),width=0.35,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc","#ab84b6"))+
  geom_signif(comparisons = list(c("Ape","Lemur"),c("Lemur","Monkey"),c("Ape","Monkey")),
              map_signif_level = F, 
              textsize = 4, 
              step_increase = 0.2,
              test = "wilcox.test")+
  labs(x = "Phylogenetic group",y="Cooperation (MIP score)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(10,160),breaks = seq(10,160,50))+
  coord_cartesian(ylim= c(10,160))+
  expand_limits(y=10)  
p8

library(gridExtra)
plots <- list(p1,p2,p3,p4,p5,p6,p7,p8)
grid.arrange(grobs = plots,ncol=4)
