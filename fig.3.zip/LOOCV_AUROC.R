library(randomForest)
library(pROC) # ����roc������auc����
library(dplyr)
library(smotefamily)

del_var <- read.table('site_bin_mro_mip_var',header = T)

pop_phyla <- read.table('3867pop.phyla',header = F)
colnames(pop_phyla) <- c("bin","phyla")

del_var <- left_join(del_var,pop_phyla,by = 'bin')

del_var_mrovar <- del_var %>%  
  group_by(sample) %>%  
  filter(mro_var == max(mro_var)) %>%  
  ungroup()

del_var_mipvar <- del_var %>%  
  group_by(sample) %>%  
  filter(mip_var == max(mip_var)) %>%  
  ungroup()

mrobin_freq <- table(del_var_mrovar$bin)
mrobin_mrovar <- aggregate(del_var_mrovar$mro_var,list(del_var_mrovar$bin),mean)
unique(rownames(mrobin_freq) == mrobin_mrovar$Group.1)
mrobin_df <- data.frame(mrobin_freq,mrobin_mrovar)[,-3]
colnames(mrobin_df) <- c("bin","Freq","mro_var")
mrobin_df <- left_join(mrobin_df,pop_phyla,by = "bin")

mipbin_freq <- table(del_var_mipvar$bin)
mipbin_mipvar <- aggregate(del_var_mipvar$mip_var,list(del_var_mipvar$bin),mean)
unique(rownames(mipbin_freq) == mipbin_mipvar$Group.1)
mipbin_df <- data.frame(mipbin_freq,mipbin_mipvar)[,-3]
colnames(mipbin_df) <- c("bin","Freq","mip_var")
mipbin_df <- left_join(mipbin_df,pop_phyla,by = "bin")

mro_bin <- mrobin_df[mrobin_df$phyla == "p__Bacillota_A",]$bin
mip_bin <- mipbin_df[mipbin_df$phyla == "p__Pseudomonadota",]$bin

pri_data <- read.table('../fig.2/site.rand_mro_mip_div',header = T)
pri_data$sample <- rownames(pri_data)

mat <- read.delim("../fig.2/npgmg_841sample.cov",header = T,row.names = 1,check.names = F)
mat_new <- as.data.frame(mat)[,pri_data$sample]
mat_new <- mat_new[rowSums(mat_new) > 0,]

mat_keybin <- as.data.frame(t(mat_new[unique(c(mro_bin,mip_bin)),]))

unique(rownames(mat_keybin) == pri_data$sample)

df <- mat_keybin
df[df != 0] <- 1

intertype <- pri_data$intertype
df_df <- data.frame(df,intertype)

roc_data_all <- list()
for (cls in levels(df_df$intertype)) {
  roc_data_all[[cls]] <- list(actuals = numeric(), preds = numeric())
}

for (i in 1:nrow(df_df)) {
  print(i)
  df_train <- df_df[-i, ]
  df_test <- df_df[i, ]
  
  df_train$intertype <- as.factor(df_train$intertype)
  rf_model <- randomForest(intertype~., data = df_train, ntree = 1000, mtry = floor(ncol(df_train) / 3))
  
  pred_prob <- predict(rf_model, df_test, type = "prob")
  
  actual_class <- as.character(df_test$intertype)
  
  for (cls in unique(df_df$intertype)) {
    actuals <- ifelse(actual_class == cls, 1, 0)
    preds <- pred_prob[, cls]

    roc_data_all[[cls]]$actuals <- c(roc_data_all[[cls]]$actuals, actuals)  
    roc_data_all[[cls]]$preds <- c(roc_data_all[[cls]]$preds, preds)
  }
}

for (cls in unique(df_df$intertype)) {
  roc_obj <- roc(roc_data_all[[cls]]$actuals, roc_data_all[[cls]]$preds, ci = TRUE)
  print(roc_obj)
  auc <- auc(roc_obj)
  plot(roc_obj, type = "l", col = "blue", lwd = 2,
       xlab = "False Positive Rate", ylab = "True Positive Rate",
       main = paste("Average ROC Curve for Class", cls))
  abline(0, 1, col = "grey")
  text(0.8, 0.2, paste("AUC =", round(auc, 2)), col = "blue", cex = 1.2)
}

roc_obj1 <- roc(roc_data_all[["Type 1"]]$actuals, roc_data_all[["Type 1"]]$preds, ci = TRUE)
roc_obj2 <- roc(roc_data_all[["Type 2"]]$actuals, roc_data_all[["Type 2"]]$preds, ci = TRUE)
roc_obj3 <- roc(roc_data_all[["Type 3"]]$actuals, roc_data_all[["Type 3"]]$preds, ci = TRUE)
roc_obj4 <- roc(roc_data_all[["Type 4"]]$actuals, roc_data_all[["Type 4"]]$preds, ci = TRUE)

p1 <- ggroc(list(type1 = roc_obj1,type2 = roc_obj2,
           type3 = roc_obj3,type4 = roc_obj4))+
  scale_color_manual(values = c("#bc587d","#3ca6cc","#ab84b6","#c2dc50"))+  
  theme_bw()+
  labs(x = "Specificty", y = "Sensivity")+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=12),axis.title.y = element_text(size=12),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=10,colour = 'black'),
        axis.text.y=element_text(size=10,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth=0.5,colour="black"),legend.text = element_text(size=4),
        legend.position = 'top')+
  annotate(geom = "segment",x=1,y=0,xend=0,yend=1)
p1
