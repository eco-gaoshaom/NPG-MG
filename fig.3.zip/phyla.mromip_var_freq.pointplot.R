library(dplyr)
library(ggplot2)

del_var <- read.table('site_bin_mro_mip_var',header = T)

pri_data <- read.table('../fig.2/site.rand_mro_mip_div',header = T)
pri_data$sample <- rownames(pri_data)

del_var <- left_join(del_var,pri_data[,c("intertype","sample")],by = "sample")
del_var <- as.data.frame(del_var)

pop_phyla <- read.table('3867pop.phyla',header = F)
colnames(pop_phyla) <- c("bin","phyla")

del_var <- left_join(del_var,pop_phyla,by = 'bin')

del_var_mean <- aggregate(del_var[,3:4],list(del_var$phyla),mean)
phy_pre <- as.data.frame(table(unique(del_var[,c(1,6)])$phyla))
unique(del_var_mean$Group.1 == phy_pre$Var1)
del_var_mean <- data.frame(del_var_mean,phy_pre)
del_var_mean$pre <- del_var_mean$Freq/184

del_var_mean <- del_var_mean[order(del_var_mean$mro_var,decreasing = T),]

sel_phy <- c("p__Bacillota_A","p__Bacteroidota","p__Pseudomonadota","p__Spirochaetota",
     "p__Bacillota","p__Bacillota_C","p__Thermoplasmatota","p__Synergistota","p__Desulfobacterota")

del_var_mean <- del_var_mean %>%
  mutate(Group.1 = ifelse(!(Group.1 %in% sel_phy), "Others", Group.1))

del_var_mean$Group.1 <- factor(del_var_mean$Group.1,levels = c(sel_phy,"Others"))


p1 <- ggplot(del_var_mean,aes(mro_var,pre))+
  geom_point(size=3,shape = 17,aes(color = Group.1))+
  scale_color_manual(values = c("#bc587d","#3ca6cc","#ab84b6","#c2dc50",
                                "#e1999e","#a596ff","#e7ca16","#7aa3ad","#f99233",
                                "#696969"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  labs(x="Mean contributions",y="Prevalence")+
  scale_x_continuous(limits = c(-0.002,0.002),breaks=seq(-0.002,0.002,0.001))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  coord_cartesian(xlim= c(-0.002,0.002),ylim = c(0,1))+
  expand_limits(x=-0.002,y=0)
p1

p2 <- ggplot(del_var_mean,aes(mip_var,pre))+
  geom_point(size=3,shape = 17,aes(color = Group.1))+
  scale_color_manual(values = c("#bc587d","#3ca6cc","#ab84b6","#c2dc50",
                                "#e1999e","#a596ff","#e7ca16","#7aa3ad","#f99233",
                                "#696969"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  labs(x="Mean contributions",y="Prevalence")+
  scale_x_continuous(limits = c(0,1.6),breaks=seq(0,1.6,0.4))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  coord_cartesian(xlim= c(0,1.6),ylim = c(0,1))+
  expand_limits(x=0,y=0)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
