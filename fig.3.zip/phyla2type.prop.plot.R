pri_data <- read.table('../fig.2/site.rand_mro_mip_div',header = T)
pri_data$sample <- rownames(pri_data)

mat <- read.delim("../fig.2/npgmg_841sample.cov",header = T,row.names = 1,check.names = F)
mat_new <- as.data.frame(mat)[,pri_data$sample]
mat_new <- mat_new[rowSums(mat_new) > 0,]

pop_phyla <- read.table('3867pop.phyla',header = F)
colnames(pop_phyla) <- c("bin","phyla")
rownames(pop_phyla) <- pop_phyla$bin

pop_baci_a <- rownames(pop_phyla[pop_phyla$phyla == "p__Bacillota_A",])
pop_pseu <- rownames(pop_phyla[pop_phyla$phyla == "p__Pseudomonadota",])

phyprop <- matrix(0,ncol(mat_new),2)
for (i in 1:ncol(mat_new)){
  bins <- c(rownames(mat_new)[mat_new[,i]> colSums(mat_new)[i] * 0.001])
  bacia_bin <- length(intersect(pop_baci_a,bins))/length(bins)
  pseu_bin <- length(intersect(pop_pseu,bins))/length(bins)
  phyprop[i,] <- c(bacia_bin,pseu_bin)
}
phyprop <- as.data.frame((phyprop))
colnames(phyprop) <- c("prop_bacia","prop_pseu")
unique(colnames(mat_new) == pri_data$sample) 
phyprop$intertype <- pri_data$intertype

phyprop$mro_types <- ifelse(!(phyprop$intertype %in% c("Type 1","Type 4")), "Others", "MRO types")
phyprop$mip_types <- ifelse(!(phyprop$intertype %in% c("Type 1","Type 2")), "Others", "MIP types")

phyprop2 <- phyprop[phyprop$prop_pseu>0,]
aggregate(phyprop[,1:2],list(phyprop$mro_types),mean)
aggregate(phyprop2[,1:2],list(phyprop2$mip_types),mean)

wilcox.test(phyprop$prop_bacia~phyprop$mro_types)
wilcox.test(phyprop$prop_pseu~phyprop$mip_types)
wilcox.test(phyprop2$prop_pseu~phyprop2$mip_types)

phyprop$intertype <- factor(phyprop$intertype,levels = c("Type 1","Type 4","Type 2","Type 3"))

p1 <- ggplot(phyprop,aes(intertype,prop_bacia))+
  geom_jitter(aes(color = intertype),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  scale_color_manual(values=c("#bc587d","#c2dc50","#3ca6cc","#ab84b6"))+
  labs(x = "Types",y="Proportion of Bacillota_A")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  coord_cartesian(ylim= c(0,1))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))
p1

phyprop$intertype <- factor(phyprop$intertype,levels = c("Type 1","Type 2","Type 3","Type 4"))

p2 <- ggplot(phyprop,aes(intertype,prop_pseu))+
  geom_jitter(aes(color = intertype),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  scale_color_manual(values=c("#bc587d","#3ca6cc","#ab84b6","#c2dc50"))+
  labs(x = "Types",y="Proportion of Pseudomonadota")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  coord_cartesian(ylim= c(0,0.15))
  #scale_y_continuous(limits = c(0,0.15),breaks=seq(0,0.15,0.03))
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)

df <- data.frame(pri_data[,c("mro","mip","X001aai","X001div")],phyprop)
df2 <- df[df$prop_pseu>0,]
df2$mip2div <- df2$mip/df2$X001div

p1 <- ggplot(df)+
  geom_point(aes(prop_bacia,mro),size=1.5,color="#3ca6cc")+
  geom_smooth(aes(prop_bacia,mro),method='lm',fill=NA,color = "black")+
  labs(x="Proportion of Bacillota_A",y="MRO score")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 0,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'bottom')+
  expand_limits(y=0.5,x=0)+
  scale_x_continuous(limits = c(0,1),breaks = seq(0,1,0.25))+
  scale_y_continuous(limits = c(0.5,0.7),breaks=seq(0.5,0.7,0.05)) 
p1

p2 <- ggplot(df2)+
  geom_point(aes(prop_pseu,mip2div),size=1.5,color="#bc587d")+
  geom_smooth(aes(prop_pseu,mip2div),method='lm',fill=NA,color = "black")+
  labs(x="Proportion of Pseudomonadota",y="MIP score (Normalized)")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 0,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'bottom')+
  expand_limits(x=0,y=10)+
  scale_x_continuous(limits = c(0,0.12),breaks = seq(0,0.12,0.03))+
  scale_y_continuous(limits = c(0.5,3),breaks=seq(0.5,3,0.5))
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=2)
