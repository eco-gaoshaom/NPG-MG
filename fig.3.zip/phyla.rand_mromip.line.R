rand_mro_mip <- read.table('phyla.random_mro_mip.table',header = T)
rand_mro_mip$pop_num <- c(2:50)

mro_df <- reshape2::melt(rand_mro_mip[,c(1,3,5,7,9,11,13)],id.vars = c("pop_num"))
mip_df <- reshape2::melt(rand_mro_mip[,c(2,4,6,8,10,12,13)],id.vars = c("pop_num"))

mro_df$variable <- factor(mro_df$variable,levels = c("rand_mro","baci_a_mro","bact_mro","baci_i_mro","pseu_mro","acti_mro"))
mip_df$variable <- factor(mip_df$variable,levels = c("rand_mip","baci_a_mip","bact_mip","baci_i_mip","pseu_mip","acti_mip"))

p1 <- ggplot(mro_df)+
  geom_line(aes(pop_num,value,color=variable))+
  #geom_ribbon(aes(x = pop_num,y = value, ymin = lower_ci, ymax = upper_ci, fill = variable), alpha = 0.2) +
  labs(x="Number of populations",y="MRO score")+
  scale_color_manual(values=c("#bebebe","#bc587d","#3ca6cc","#c2dc50","#ab84b6","#a596ff"))+
  scale_fill_manual(values=c("#bebebe","#bc587d","#3ca6cc","#c2dc50","#ab84b6","#a596ff"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),
        panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=5),
        legend.position = 'right')+
  expand_limits(x=0,y=0.5)+
  scale_x_continuous(limits = c(0,50),breaks = seq(0,50,10))+
  scale_y_continuous(limits = c(0.5,0.6),breaks=seq(0.5,0.6,0.02))  
p1

p2 <- ggplot(mip_df)+
  geom_line(aes(pop_num,value,color=variable))+
  #geom_ribbon(aes(x = pop_num,y = value, ymin = lower_ci, ymax = upper_ci, fill = variable), alpha = 0.2) +
  labs(x="Number of populations",y="MIP score")+
  scale_color_manual(values=c("#bebebe","#bc587d","#3ca6cc","#c2dc50","#ab84b6","#a596ff"))+
  scale_fill_manual(values=c("#bebebe","#bc587d","#3ca6cc","#c2dc50","#ab84b6","#a596ff"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),
        panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=5),
        legend.position = 'right')+
  expand_limits(x=0,y=0)+
  scale_x_continuous(limits = c(0,50),breaks = seq(0,50,10))+
  scale_y_continuous(limits = c(0,80),breaks=seq(0,80,20)) 
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
