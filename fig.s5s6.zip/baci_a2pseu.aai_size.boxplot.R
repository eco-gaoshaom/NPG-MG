char <- read.table('../fig.4/3867sgb.char',header = T)
char <- char[char$phyla != "p__Unclassified",]
rownames(char) <- char$bin

phy_char <- aggregate(char[,c(2:11,13:15)],list(char$phyla),mean)
phy_char[c(3,7,19,21),]
phy_char$length <- phy_char$length/1000

char_baci_a <- char[char$phyla == "p__Bacillota_A",]
char_pseu <- char[char$phyla == "p__Pseudomonadota",]

aai_df <- rbind(char_baci_a,char_pseu)

p1 <- ggplot(aai_df,aes(phyla,aai_mean))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = phyla),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = phyla),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Phyla",y="Mean AAI (%)")+
  geom_signif(comparisons = list(c("p__Bacillota_A","p__Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(35,45),breaks = seq(35,45,2.5))+
  coord_cartesian(ylim= c(35,45))+
  expand_limits(y=35)  
p1

len_df <- rbind(char_baci_a,char_pseu)[,c("phyla","length")]

gtdb_source <- read.delim('../fig.4/bac120_metadata_r220.cut.re',header = F)
colnames(gtdb_source) <- c("name","com","con","length","source","phyla")
gtdbrep <- read.table('../fig.4/bac120_taxonomy_r220_reps.name',header = F)
gtdbrep_source <- gtdb_source[gtdb_source$name %in% gtdbrep$V1,]

len_df2 <- gtdbrep_source[gtdbrep_source$phyla %in% c("p__Bacillota_A","p__Pseudomonadota"),c("phyla","length")]

len_dfs <- rbind(len_df,len_df2)
len_dfs$length <- len_dfs$length/1000
wilcox.test(len_dfs$length~len_dfs$phyla)

p2 <- ggplot(len_dfs,aes(phyla,length))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = phyla),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = phyla),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Phyla",y="Genome size (�� 103)")+
  geom_signif(comparisons = list(c("p__Bacillota_A","p__Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,15000),breaks = seq(0,15000,5000))+
  coord_cartesian(ylim= c(0,15000))+
  expand_limits(y=0)  
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
