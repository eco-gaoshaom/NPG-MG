baci_a_df <- read.table('baci_a.ext_input.chem.freq',header = T)
baci_a_df$chem2 <- factor(c(1:10),levels = c(10:1))

p1 <- ggplot(baci_a_df)+
  geom_point(aes(chem2,freq),size=2.5,shape=16,color = "#3ca6cc")+
  geom_segment(aes(y = 0.99, yend = freq, x = chem2, xend = reorder(chem2,freq)),color = "#3ca6cc") + 
  labs(x="Input compound",y='Frequency in Bacillota_A')+
  coord_flip()+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,vjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.99,1),breaks=seq(0.99,1,0.005))+
  expand_limits(y=0.99)
p1
#we then identify what chemical pseu output would be mostly absorbed by other pops
pseu_df <- read.table('pseu.ext_output.chem.freq',header = T)
pseu_df$chem2 <- factor(c(1:10),levels = c(10:1))

p2 <- ggplot(pseu_df)+
  geom_point(aes(chem2,freq),size=2.5,shape=16,color = "#bc587d")+
  geom_segment(aes(y = 0.4, yend = freq, x = chem2, xend = reorder(chem2,freq)),color = "#bc587d") + 
  labs(x="Output compound",y='Frequency in populations')+
  coord_flip()+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,vjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.4,1),breaks=seq(0.4,1,0.3))+
  expand_limits(y=0.4)

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
