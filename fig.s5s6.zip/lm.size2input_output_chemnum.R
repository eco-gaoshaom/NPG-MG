char <- read.table('3867sgb.char',header = T)
char <- char[char$phyla != "p__Unclassified",]
rownames(char) <- char$bin

phy_char <- aggregate(char[,c(2:11,13:16)],list(char$phyla),mean)
phy_char[c(3,7,19,21),]
phy_char$length <- phy_char$length/1000

cor.test(phy_char$length,phy_char$in_num)
cor.test(phy_char$length,phy_char$out_num)

p1 <- ggplot(phy_char, aes(length,in_num)) +
  geom_point(color = "#999999",shape = 17,size = 3) +  
  geom_smooth(method = "lm", se = FALSE) +  
  labs(x = "Mean genome size (�� 103)",y = "Mean number of input compounds") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(700,3500),breaks=seq(700,3500,700),labels = scales::comma)+
  scale_y_continuous(limits = c(40,160),breaks=seq(40,160,40))+
  coord_cartesian(xlim= c(700,3500),ylim = c(40,160))+
  expand_limits(x=700,y=40)
p1

p2 <- ggplot(phy_char, aes(length,out_num)) +
  geom_point(color = "#999999",shape = 17,size = 3) +  
  geom_smooth(method = "lm", se = FALSE) +  
  labs(x = "Mean genome size (�� 103)",y = "Mean number of out compounds") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(700,3500),breaks=seq(700,3500,700),labels = scales::comma)+
  scale_y_continuous(limits = c(9,36),breaks=seq(9,36,9))+
  coord_cartesian(xlim= c(700,3500),ylim = c(9,35))+
  expand_limits(x=700,y=9)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
