data <- read.table('seqkit.SGBs_proportion.cov',header = T,row.names = 1)
div <- matrix(apply(data, 2, function(x) sum(x > 0)),5,9)
colnames(div) <- c("Atelidae",	"Indriidae",	"Cercopithecidae",	"Cheirogaleidae",
                   "Lemuridae",	"Hylobatidae",	"Callitrichidae",	"Cebidae",	"Hominidae")
rownames(div) <- c("100","20","40","60","80")
div <- t(div)
div_melt <- reshape2::melt(div,id.vars = c(rownames(div)))
div_melt$Var1 <- factor(div_melt$Var1,levels = c("Cheirogaleidae",	"Callitrichidae",	"Cebidae",	"Atelidae",
                                                 "Indriidae",	"Lemuridae",	"Hylobatidae",	"Hominidae",	"Cercopithecidae"))
div_melt$Var2 <- as.numeric(div_melt$Var2)

ggplot(div_melt)+
  geom_line(aes(x=Var2,y=value,color= Var1),linewidth=0.5)+
  geom_point(aes(x=Var2,y=value,color= Var1),size=2)+
  scale_color_manual(values=c("#e7ca16","#f99233",
                              "#bc587d","#e1999e",
                              "#ab84b6","#e4b9c3",
                              "#c2dc50","#a596ff",
                              "#3ca6cc"))+#+,"#a596ff","#7aa3ad"
  theme_bw()+
  labs(x = "Proportion of metagenomic reads", y = "Identified SGBs")+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=12),axis.title.y = element_text(size=12),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=10,colour = 'black'),
        axis.text.y=element_text(size=10,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth=0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+expand_limits(x=0,y=0)+
  scale_x_continuous(limits =c(20,100),breaks = seq(20,100,20),labels = scales::comma)+
  scale_y_continuous(limits =c(0,900),breaks = seq(0,900,300),labels = scales::comma)+
  coord_cartesian(xlim = c(20,100),ylim=c(0,900))
