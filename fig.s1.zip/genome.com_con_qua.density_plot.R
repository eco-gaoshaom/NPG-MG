data <- read.delim('16340hq.bins.com_con.csv',header = T,sep = ',')
rownames(data) <- data$genome
bin2pop <- read.table('npgmg.pop2genome.map',header = F)

rep_pop <- unique(bin2pop$V2)
pop_qua <- data[rep_pop,]

library(ggplot2)

p1 <- ggplot(pop_qua,aes(x=completeness))+
  geom_density(color="#bc587d",fill="#bc587d",alpha=0.5)+
  labs(x="Completeness (%)",y="Density")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=12),
        legend.position = 'bottom')+
  expand_limits(x=90,y=0)+
  scale_x_continuous(limits = c(90,100),breaks=seq(90,100,2.5))+
  scale_y_continuous(limits = c(0,0.2),breaks=seq(0,0.2,0.05))+
  geom_vline(xintercept=96.26,linetype=2,color="#bc587d",
             linewidth=1)
p1

p2 <- ggplot(pop_qua,aes(x=contamination))+
    geom_density(color="#3ca6cc",fill="#3ca6cc",alpha=0.5)+
    labs(x="Contamination (%)",y="Density")+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
          axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
          axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
          axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
          axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=12),
          legend.position = 'bottom')+
    expand_limits(x=0,y=0)+
    scale_x_continuous(limits = c(0,5),breaks=seq(0,5,1))+
  scale_y_continuous(limits = c(0,1.5),breaks=seq(0,1.5,0.5))+
    geom_vline(xintercept=0.715,linetype=2,color="#3ca6cc",
               linewidth=1)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
