library(ggplot2)
data <- read.table('seqkit.SGBs_proportion.cov',header = T,row.names = 1)

tpr_fpr <- function(df){
  tp_fp <- numeric(8)
  column_sums <- colSums(df)
  
  first_col_above_threshold_rows <- rownames(df)[df[, 1] > column_sums[1] / 1000]
  
  for (col in 2:5) {
    
    threshold <- column_sums[col] / 1000
    
    above_threshold_rows <- rownames(df)[df[, col] > threshold]
    
    tp <- length(intersect(above_threshold_rows, first_col_above_threshold_rows))
  
    fp <- length(setdiff(above_threshold_rows, first_col_above_threshold_rows))
    
    tp_fp[col - 1] <- tp/length(first_col_above_threshold_rows)
    tp_fp[col + 3] <- fp/length(first_col_above_threshold_rows)
  }
  tp_fp
}

tp_fp_mt <- matrix(0,9,8)
for (i in 1:9){
  df <- data[,(5*i-4):(5*i)]
  tp_fp_mt[i,] <- tpr_fpr(df)
}

fam <- c("Atelidae",	"Indriidae",	"Cercopithecidae",	"Cheirogaleidae",
         "Lemuridae",	"Hylobatidae",	"Callitrichidae",	"Cebidae",	"Hominidae")

rownames(tp_fp_mt) <- fam
colnames(tp_fp_mt) <- c("20","40","60","80","20","40","60","80")

mt_melt1 <- reshape2::melt(tp_fp_mt[,1:4],id.vars = c(rownames(tp_fp_mt)))
mt_melt1$Var1 <- factor(mt_melt1$Var1,levels = 
 c("Cheirogaleidae",	"Callitrichidae",	"Cebidae",	"Atelidae",
   "Indriidae",	"Lemuridae",	"Hylobatidae",	"Hominidae",	"Cercopithecidae"))
mt_melt1$Var2 <- factor(mt_melt1$Var2,levels = c("20","40","60","80"))

p1 <- ggplot(mt_melt1,aes(Var2,Var1))+
  geom_point(aes(fill =value),size = 6,alpha=1,shape=22,stroke = 0.5)+
  scale_size_area(max_size = 8,breaks = 2)+
  theme_bw()+
  scale_fill_gradient(low = "#3ca6cc",high = "#bc587d",limits = c(0, 1))+

  theme(panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,size=12,angle = 0,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 0),
        axis.line = element_line(linewidth =1,colour="black"),
        legend.text = element_text(size=13),
        legend.position = 'left')

div <- matrix(apply(data, 2, function(x) sum(x > 0)),5,9)
colnames(div) <- c("Atelidae",	"Indriidae",	"Cercopithecidae",	"Cheirogaleidae",
                   "Lemuridae",	"Hylobatidae",	"Callitrichidae",	"Cebidae",	"Hominidae")
rownames(div) <- c("100","20","40","60","80")

raw_div <- as.data.frame(div[1,])
raw_div$fam <- rownames(raw_div)
colnames(raw_div) <- c("div","Family")
raw_div$Family <- factor(raw_div$Family,levels =  c("Cheirogaleidae",	"Callitrichidae",	"Cebidae",	"Atelidae",
                                                    "Indriidae",	"Lemuridae",	"Hylobatidae",	"Hominidae",	"Cercopithecidae"))

p2 <- ggplot(raw_div,aes(Family,div))+
  geom_bar(fill = "#3ca6cc",stat = 'identity',position = 'dodge',width =0.3)+
  labs(x="Family",y='Richness')+
  theme_bw()+coord_flip(ylim = c(0,900))+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,size=12,angle = 0,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 0),panel.border = element_blank(),
        axis.line = element_line(linewidth =1,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  scale_y_continuous(breaks = seq(0,900,300))#+
  #coord_cartesian(ylim = c(0,900))

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=2)
