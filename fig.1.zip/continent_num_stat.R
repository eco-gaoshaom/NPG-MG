data <- read.delim('841sample.metadata',header = T)

con2cou <- unique(data[,c("Continent","Country")])
con2cou_num <- aggregate(con2cou$Country,list(con2cou$Continent),length)
con2cou_num

con2spe <- unique(data[,c("Continent","Primate_species")])
con2spe_num <- aggregate(con2spe$Primate_species,list(con2spe$Continent),length)
con2spe_num

con2sam <- unique(data[,c("Continent","Sample_name")])
con2sam_num <- aggregate(con2sam$Sample_name,list(con2sam$Continent),length)
con2sam_num

con2w_c <- unique(data[,c("Continent","Env_group","Sample_name")])
con2w_c_num <- aggregate(con2w_c$Sample_name,list(con2w_c$Continent,con2w_c$Env_group),length)
con2w_c_num

con2bin <- aggregate(data$Bin_number,list(data$Continent),sum)
con2bin
