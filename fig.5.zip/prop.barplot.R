otu_table <- read.delim('asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv_char <- read.table('asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('316sample.char',header = F)

asv_both <- intersect(rownames(otu_table),asv_char$V1)
asv_char_sel <- asv_char[asv_both,]

otu_table_order <- otu_table[order(match(rownames(otu_table), asv_char_sel$V1)),]
otu_table_order$phyla <- asv_char_sel$V3
phyla_table <- aggregate(otu_table_order[,1:(ncol(otu_table_order)-1)],list(otu_table_order$phyla),sum)
rownames(phyla_table) <- phyla_table$Group.1
phyla_tablet <- as.data.frame(t(phyla_table[,-1]))
colnames(phyla_tablet) <- phyla_table$Group.1

phyla_tablet_order <- phyla_tablet[order(match(rownames(phyla_tablet), sam_char$V1)),]
phyla_tablet_order$group <- sam_char$V2
phyla_tablet_order <- phyla_tablet_order[rowSums(phyla_tablet_order[,1:25]) >= 10000,]
phyla_tablet_order[,1:25] <- phyla_tablet_order[,1:25]/rowSums(phyla_tablet_order[,1:25])

aggregate(phyla_tablet_order[,1:25],list(phyla_tablet_order$group),mean)
wilcox.test(phyla_tablet_order$p__Bacillota_A~phyla_tablet_order$group)
wilcox.test(phyla_tablet_order$p__Pseudomonadota~phyla_tablet_order$group)

rela_df <- aggregate(phyla_tablet_order[,1:25],list(phyla_tablet_order$group),mean)
rela_df <- reshape2::melt(rela_df,id.vars = c("Group.1"))

phyrel <- as.data.frame(colMeans(phyla_tablet_order[,1:25]))
phyrel$phyla <- rownames(phyrel)
phyrel <- phyrel[order(phyrel$`colMeans(phyla_tablet_order[, 1:25])`,decreasing = T),]
sel_phy <- c(rownames(phyrel)[2:9],"Unassigned")

rela_df$variable <- as.character(rela_df$variable)
rela_df <- rela_df %>%
  mutate(variable = ifelse(!(variable %in% sel_phy), "Others", variable))
rela_df <- aggregate(rela_df[,3],list(rela_df$Group.1,rela_df$variable),sum)

rela_df$Group.1 <- factor(rela_df$Group.1,levels = c("healthy","unhealthy"))
rela_df$Group.2 <- factor(rela_df$Group.2,levels = c(sel_phy,"Others"))

p1 <- ggplot(rela_df,aes(Group.1,x,fill=Group.2))+
  geom_bar(stat = 'identity',position = 'stack',width =0.25)+
  scale_fill_manual(values = c("#ab84b6","#bc587d","#3ca6cc","#c2dc50",
                                "#e1999e","#a596ff","#e7ca16","#7aa3ad","#696969",
                                "#c6c6c6"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=8,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=6),
        legend.position = 'top')+
  labs(x="Status",y="Proportion")+
  #scale_x_continuous(limits = c(0.45,0.6),breaks=seq(0.45,0.6,0.05))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  expand_limits(y=0)
p1

#then compare the proportion of phyla in gi healthy and unhealty group

otu_table <- read.delim('asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv_char <- read.table('asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('316sample.char',header = F)

otu_table[otu_table>0]=1

asv_both <- intersect(rownames(otu_table),asv_char$V1)
asv_char_sel <- asv_char[asv_both,]

otu_table_order <- otu_table[order(match(rownames(otu_table), asv_char_sel$V1)),]
otu_table_order$phyla <- asv_char_sel$V3
phyla_table <- aggregate(otu_table_order[,1:(ncol(otu_table_order)-1)],list(otu_table_order$phyla),sum)
rownames(phyla_table) <- phyla_table$Group.1
phyla_tablet <- as.data.frame(t(phyla_table[,-1]))
colnames(phyla_tablet) <- phyla_table$Group.1

phyla_tablet_order2 <- phyla_tablet[order(match(rownames(phyla_tablet), sam_char$V1)),]
phyla_tablet_order2$group <- sam_char$V2
phyla_tablet_order2 <- phyla_tablet_order2[rownames(phyla_tablet_order),]
group_div <- as.data.frame(rowSums(phyla_tablet_order2[,1:25]))
phyla_tablet_order2[,1:25] <- phyla_tablet_order2[,1:25]/rowSums(phyla_tablet_order2[,1:25])
aggregate(phyla_tablet_order2[,1:25],list(phyla_tablet_order2$group),mean)
wilcox.test(phyla_tablet_order2$p__Bacillota_A~phyla_tablet_order2$group)
wilcox.test(phyla_tablet_order2$p__Pseudomonadota~phyla_tablet_order2$group)


prop_df <- aggregate(phyla_tablet_order2[,1:25],list(phyla_tablet_order2$group),mean)
prop_df <- reshape2::melt(prop_df,id.vars = c("Group.1"))
sel_phy <- sel_phy
prop_df$variable <- as.character(prop_df$variable)
prop_df <- prop_df %>%
  mutate(variable = ifelse(!(variable %in% sel_phy), "Others", variable))
prop_df <- aggregate(prop_df[,3],list(prop_df$Group.1,prop_df$variable),sum)

prop_df$Group.1 <- factor(prop_df$Group.1,levels = c("healthy","unhealthy"))
prop_df$Group.2 <- factor(prop_df$Group.2,levels = c(sel_phy,"Others"))

p2 <- ggplot(prop_df,aes(Group.1,x,fill=Group.2))+
  geom_bar(stat = 'identity',position = 'stack',width =0.25)+
  scale_fill_manual(values = c("#ab84b6","#bc587d","#3ca6cc","#c2dc50",
                               "#e1999e","#a596ff","#e7ca16","#7aa3ad","#696969",
                               "#c6c6c6"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=8,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=6),
        legend.position = 'right')+
  labs(x="Status",y="Proportion")+
  #scale_x_continuous(limits = c(0.45,0.6),breaks=seq(0.45,0.6,0.05))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  expand_limits(y=0)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=2)


#boxplot for each phyla
p3 <- ggplot(phyla_tablet_order2,aes(group,p__Bacillota_A))+
  #geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Group",y="Proportion of Bacillota_A")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,0.6),breaks = seq(0,0.6,0.2))+
  coord_cartesian(ylim= c(0,0.6))+
  expand_limits(y=0) 
p3

p4 <- ggplot(phyla_tablet_order2,aes(group,p__Pseudomonadota))+
  #geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Group",y="Proportion of Pseudomonadota")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,0.25),breaks = seq(0,0.25,0.05))+
  coord_cartesian(ylim= c(0,0.25))+
  expand_limits(y=0) 
p4

library(gridExtra)
plots <- list(p1,p3,p4)
grid.arrange(grobs = plots,ncol=1)
