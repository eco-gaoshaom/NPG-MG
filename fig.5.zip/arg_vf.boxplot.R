gtdb_char <- read.table('gtdb.char',header = T)

pseu_char <- gtdb_char[gtdb_char$phyla == "p__Pseudomonadota",2:3]
bacia_char <- gtdb_char[gtdb_char$phyla == "p__Bacillota_A",2:3]

sgb_char <- read.table('../fig.4/3867sgb.char',header = T)
pseu_char2 <- sgb_char[sgb_char$phyla == "p__Pseudomonadota",2:3]
bacia_char2 <- sgb_char[sgb_char$phyla == "p__Bacillota_A",2:3]

group <- c(replicate(nrow(pseu_char)+nrow(bacia_char),"gtdb"),
           replicate(nrow(pseu_char2)+nrow(bacia_char2),"sbg"))
phylas <- c(replicate(nrow(pseu_char),"Pseudomonadota"),replicate(nrow(bacia_char),"Bacillota_A"),
            replicate(nrow(pseu_char2),"Pseudomonadota"),replicate(nrow(bacia_char2),"Bacillota_A"))
df <- rbind(pseu_char,bacia_char,pseu_char2,bacia_char2)
df <- as.data.frame(cbind(df,group,phylas))

p5 <- ggplot(df,aes(phylas,arg_num))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#e7ca16","#a596ff"))+
  labs(x = "Phyla",y="Number of ARGs")+
  geom_signif(comparisons = list(c("Bacillota_A","Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  #scale_y_continuous(limits = c(0,100),breaks = seq(0,100,25))+
  coord_cartesian(ylim= c(0,100))+
  expand_limits(y=0) 
p5

p6 <- ggplot(df,aes(phylas,vf_num))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#e7ca16","#a596ff"))+
  labs(x = "Phyla",y="Number of ARGs")+
  geom_signif(comparisons = list(c("Bacillota_A","Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  #scale_y_continuous(limits = c(0,300),breaks = seq(0,300,60))+
  coord_cartesian(ylim= c(0,300))+
  expand_limits(y=0) 
p6

library(gridExtra)
plots <- list(p1,p3,p5,p2,p4,p6)
grid.arrange(grobs = plots,ncol=3)
