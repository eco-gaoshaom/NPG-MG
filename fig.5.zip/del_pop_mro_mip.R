library(XML)
library(methods)
library(xml2)
library(RevEcoR)
library(vegan)
library(ggplot2)
library(dplyr)

del_var <- read.table('site_bin_mro_mip_var',header = T)

otu_table <- read.delim('asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
otu_table_sel <- otu_table[1:3838,colSums(otu_table) >= 10000]

asv_char <- read.table('asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('316sample.char',header = F)

rownames(sam_char) <- sam_char$V1
sam_char_sel <- sam_char[colnames(otu_table_sel),]
status <- sam_char_sel$V2

pop_phyla <- unique(asv_char[,2:3])
rownames(pop_phyla) <- pop_phyla$V2
colnames(pop_phyla) <- c("bin","phyla")

del_var <- left_join(del_var,pop_phyla,by = 'bin')

del_var_mrovar <- del_var %>%  
  group_by(sample) %>%  
  filter(mro_var == max(mro_var)) %>%  
  ungroup()

del_var_mipvar <- del_var %>%  
  group_by(sample) %>%  
  filter(mip_var == max(mip_var)) %>%  
  ungroup()

mrobin_freq <- table(del_var_mrovar$bin)
mrobin_mrovar <- aggregate(del_var_mrovar$mro_var,list(del_var_mrovar$bin),mean)
unique(rownames(mrobin_freq) == mrobin_mrovar$Group.1)
mrobin_df <- data.frame(mrobin_freq,mrobin_mrovar)[,-3]
colnames(mrobin_df) <- c("bin","Freq","mro_var")
mrobin_df <- left_join(mrobin_df,pop_phyla,by = "bin")

mipbin_freq <- table(del_var_mipvar$bin)
mipbin_mipvar <- aggregate(del_var_mipvar$mip_var,list(del_var_mipvar$bin),mean)
unique(rownames(mipbin_freq) == mipbin_mipvar$Group.1)
mipbin_df <- data.frame(mipbin_freq,mipbin_mipvar)[,-3]
colnames(mipbin_df) <- c("bin","Freq","mip_var")
mipbin_df <- left_join(mipbin_df,pop_phyla,by = "bin")

del_var_mean <- aggregate(del_var[,3:4],list(del_var$phyla),mean)
phy_pre <- as.data.frame(table(unique(del_var[,c(1,5)])$phyla))
unique(del_var_mean$Group.1 == phy_pre$Var1)
del_var_mean <- data.frame(del_var_mean,phy_pre)
del_var_mean$pre <- del_var_mean$Freq/269

del_var_mean <- del_var_mean[order(del_var_mean$mro_var,decreasing = T),]

sel_phy <- c("p__Bacillota","p__Actinomycetota","p__Bacillota_C",      
           "p__Bacillota_A" ,"p__Spirochaetota","p__Verrucomicrobiota",
            "p__Bacillota_I","p__Bacteroidota","p__Pseudomonadota")

del_var_mean <- del_var_mean %>%
  mutate(Group.1 = ifelse(!(Group.1 %in% sel_phy), "Others", Group.1))

del_var_mean$Group.1 <- factor(del_var_mean$Group.1,levels = c("p__Bacillota_A","p__Bacteroidota","p__Pseudomonadota",
                                                               "p__Spirochaetota","p__Bacillota","p__Bacillota_C",
                                                               "p__Actinomycetota","p__Verrucomicrobiota","p__Bacillota_I","Others"))

p1 <- ggplot(del_var_mean,aes(mro_var,pre))+
  geom_point(size=3,shape = 17,aes(color = Group.1))+
  scale_color_manual(values = c("#3ca6cc","#ab84b6","#bc587d","#c2dc50",
                                "#e1999e","#a596ff","#e7ca16","#7aa3ad","#e4b9c3",
                                "#c6c6c6"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  labs(x="Mean contributions",y="Prevalence")+
  scale_x_continuous(limits = c(-0.0055,0.0025),breaks=seq(-0.0055,0.0025,0.002))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  coord_cartesian(xlim= c(-0.0055,0.0025),ylim = c(0,1))+
  expand_limits(x=-0.0055,y=0)
p1

p2 <- ggplot(del_var_mean,aes(mip_var,pre))+
  geom_point(size=3,shape = 17,aes(color = Group.1))+
  scale_color_manual(values = c("#3ca6cc","#ab84b6","#bc587d","#c2dc50",
                                "#e1999e","#a596ff","#e7ca16","#7aa3ad","#e4b9c3",
                                "#c6c6c6"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  labs(x="Mean contributions",y="Prevalence")+
  scale_x_continuous(limits = c(0,2.4),breaks=seq(0,2.4,0.6))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  coord_cartesian(xlim= c(0,2.4),ylim = c(0,1))+
  expand_limits(x=0,y=0)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)



#we would like to use the key pop to predict health status
library(dplyr)
library(randomForest)
library(caret)
library(vegan)
library(smotefamily)
library(pROC) # ����roc������auc����

otu_table <- read.delim('asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv_char <- read.table('asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('316sample.char',header = F)
rownames(sam_char) <- sam_char$V1

asv_both <- intersect(rownames(otu_table),asv_char$V1)
asv_char_sel <- asv_char[asv_both,]
otu_table_order <- otu_table[order(match(rownames(otu_table), asv_char_sel$V1)),]
otu_table_order$genome <- asv_char_sel$V2
gen_table <- aggregate(otu_table_order[,1:(ncol(otu_table_order)-1)],list(otu_table_order$genome),sum)
rownames(gen_table) <- gen_table$Group.1
gen_table <- as.data.frame(gen_table[,-1])
gen_table <- gen_table[,colSums(gen_table) >= 10000]
mat_new <- gen_table[rownames(gen_table) != "Unassigned", ]

mro_bin <- mrobin_df[mrobin_df$phyla == "p__Bacillota_A",]$bin
mip_bin <- mipbin_df[mipbin_df$phyla == "p__Pseudomonadota",]$bin

mromipbin_rel <- as.data.frame(t(mat_new[unique(mro_bin,mip_bin),]))
mromipbin_rel[mromipbin_rel > 0] <- 1

health <- sam_char[colnames(mat_new),2]

df_df <- data.frame(health,mromipbin_rel)

roc_data_all <- list()
for (cls in levels(df$health)) {
  roc_data_all[[cls]] <- list(actual = numeric(), preds = numeric())
}

for (i in 1:nrow(df_df)) {
  print(i)
  df_train <- df_df[-i, ]
  df_test <- df_df[i, ]
  
  df_train$health <- as.factor(df_train$health)
  rf_model <- randomForest(health ~ ., data = df_train, ntree = 1000, mtry = floor(ncol(df_train) / 3))

  pred_prob <- predict(rf_model, df_test, type = "prob")
  
  actual_class <- as.character(df_test$health)
  
  for (cls in unique(df_df$health)) {
    actuals <- ifelse(actual_class == cls, 1, 0)
    preds <- pred_prob[, cls]
    
    roc_data_all[[cls]]$actuals <- c(roc_data_all[[cls]]$actuals, actuals)  
    roc_data_all[[cls]]$preds <- c(roc_data_all[[cls]]$preds, preds)
  }
}

roc_obj1 <- roc(roc_data_all[["healthy"]]$actuals, roc_data_all[["healthy"]]$preds, ci = TRUE)
roc_obj2 <- roc(roc_data_all[["unhealthy"]]$actuals, roc_data_all[["unhealthy"]]$preds, ci = TRUE)

p1 <- ggroc(list(Unhealthy = roc_obj2),color = "#bc587d")+
  theme_bw()+
  labs(x = "Specificty", y = "Sensivity")+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=12),axis.title.y = element_text(size=12),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=10,colour = 'black'),
        axis.text.y=element_text(size=10,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth=0.5,colour="black"),legend.text = element_text(size=4),
        legend.position = 'top')+
  annotate(geom = "segment",x=1,y=0,xend=0,yend=1)
p1
