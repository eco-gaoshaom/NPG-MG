char <- read.table('mapped_genomes.char',header = T)

pseu_char <- char[char$phyla == "p__Pseudomonadota",]
bacia_char <- char[char$phyla == "p__Bacillota_A",]
wilcox.test(pseu_char$arg_num,bacia_char$arg_num)
wilcox.test(pseu_char$vf_num,bacia_char$vf_num)

char_mean <- aggregate(char[,2:3],list(char$phyla),mean)
char_mean <- char_mean[order(char_mean$vf_num,decreasing = T),]
char_mean_df <- reshape2::melt(char_mean,id.vars = c("Group.1"))
char_mean_df$Group.1 <- factor(char_mean_df$Group.1,levels = rev(char_mean$Group.1))

ggplot(char_mean_df,aes(Group.1,value,fill=variable))+
  geom_bar(stat = 'identity',position = 'dodge',width =0.5)+
  scale_fill_manual(values = c("#3ca6cc","#bc587d"))+
  labs(x="Phyla",y='Value')+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,size=12,colour = 'black'),
        axis.text.y=element_text(size=8,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(size=1,colour="black"),legend.text = element_text(size=13),
        legend.position = 'right')+
  scale_y_continuous(breaks = seq(0,65,13))+
  coord_flip(ylim = c(0,65))
