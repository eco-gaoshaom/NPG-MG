otu_table <- read.delim('asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv.char <- read.table('asv.char',header = F)
rownames(asv.char) <- asv.char$V1
sam_char <- read.table('316sample.char',header = F)

asv_both <- intersect(rownames(otu_table),asv.char$V1)
asv.char_sel <-  asv.char[asv_both,]
otu_table_order <- otu_table[order(match(rownames(otu_table), asv.char_sel$V1)),]
otu_table_order$genome <- asv.char_sel$V2
gen_table <- aggregate(otu_table_order[,1:(ncol(otu_table_order)-1)],list(otu_table_order$genome),sum)
rownames(gen_table) <- gen_table$Group.1
gen_table <- as.data.frame(gen_table[,-1])
gen_table <- gen_table[1:1205,colSums(gen_table) >= 10000]
mat_new <- gen_table

df <- read.table('site.rand_mro_mip_div3',header = T)

rownames(sam_char) <- sam_char$V1
sam_char_sel <- sam_char[colnames(mat_new),]
unique(rownames(df) == rownames(sam_char_sel))
health <- sam_char_sel$V2

df$group <- health

wilcox.test(df$mro~df$group)
wilcox.test(df$mip~df$group)

p1 <- ggplot(df,aes(group,mro))+
  #geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Group",y="MRO score")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0.5,0.65),breaks = seq(0.5,0.65,0.05))+
  coord_cartesian(ylim= c(0.5,0.65))+
  expand_limits(y=0.5) 
p1

p2 <- ggplot(df,aes(group,mip))+
  #geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Group",y="MIP score")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(25,100),breaks = seq(25,100,25))+
  coord_cartesian(ylim= c(25,100))+
  expand_limits(y=25) 
p2

library(gridExtra)
plots <- list(p3,p4,p1,p2)
grid.arrange(grobs = plots,ncol=2)
