library(dplyr)
library(ggplot2)

del_var <- read.table('../fig.3/site_bin_mro_mip_var',header = T)

pri_data <- read.table('../fig.2/site.rand_mro_mip_div',header = T)
pri_data$sample <- rownames(pri_data)

pop_phyla <- read.table('../fig.3/3867pop.phyla',header = F)
colnames(pop_phyla) <- c("bin","phyla")

del_var <- left_join(del_var,pop_phyla,by = 'bin')

del_var_mean <- aggregate(del_var[,3:4],list(del_var$phyla),mean)

binfreq <- as.data.frame(table(del_var$bin))
rownames(binfreq) <- binfreq$Var1

del_var_mrovar <- del_var %>%  
  group_by(sample) %>%  
  filter(mro_var == max(mro_var)) %>%  
  ungroup()

del_var_mipvar <- del_var %>%  
  group_by(sample) %>%  
  filter(mip_var == max(mip_var)) %>%  
  ungroup()

mrobin_mrovar <- aggregate(del_var_mrovar$mro_var,list(del_var_mrovar$bin),mean)
mrobin_freq <- as.data.frame(table(del_var_mrovar$bin))
unique(mrobin_freq$Var1 == mrobin_mrovar$Group.1)
mrobin_df <- data.frame(mrobin_freq,mrobin_mrovar)[,-3]
colnames(mrobin_df) <- c("bin","Freq","mro_var")
mrobin_df <- left_join(mrobin_df,pop_phyla,by = "bin")

mipbin_mipvar <- aggregate(del_var_mipvar$mip_var,list(del_var_mipvar$bin),mean)
mipbin_freq <- as.data.frame(table(del_var_mipvar$bin))
unique(mipbin_freq$Var1 == mipbin_mipvar$Group.1)
mipbin_df <- data.frame(mipbin_freq,mipbin_mipvar)[,-3]
colnames(mipbin_df) <- c("bin","Freq","mip_var")
mipbin_df <- left_join(mipbin_df,pop_phyla,by = "bin")

mrobin_df <- mrobin_df[mrobin_df$phyla == "p__Bacillota_A",]
mipbin_df <- mipbin_df[mipbin_df$phyla == "p__Pseudomonadota",]

p1 <- ggplot(mrobin_df,aes(mro_var,Freq))+
  geom_point(size=3,shape = 17,color = "#3ca6cc")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=4),
        legend.position = 'none')+
  labs(x="Mean contributions",y="Frequency")+
  scale_x_continuous(limits = c(0,0.008),breaks=seq(0,0.008,0.004))+
  scale_y_continuous(limits = c(0,30),breaks=seq(0,30,10))+
  coord_cartesian(xlim= c(0,0.008),ylim = c(0,30))+
  expand_limits(x=0,y=0)
p1

p2 <- ggplot(mipbin_df,aes(mip_var,Freq))+
  geom_point(size=3,shape = 17,color = "#bc587d")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black'),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=4),
        legend.position = 'none')+
  labs(x="Mean contributions",y="Frequency")+
  scale_x_continuous(limits = c(0,6),breaks=seq(0,6,2))+
  scale_y_continuous(limits = c(0,20),breaks=seq(0,20,5))+
  coord_cartesian(xlim= c(0,6),ylim = c(0,20))+
  expand_limits(x=0,y=0)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=2)

mrobin <- mrobin_df[mrobin_df$phyla == "p__Bacillota_A",]$bin
mipbin <- mipbin_df[mipbin_df$phyla == "p__Pseudomonadota",]$bin

mrobin_sample <- unique(del_var_mrovar[del_var_mrovar$bin %in% mrobin,]$sample)
mipbin_sample <- unique(del_var_mipvar[del_var_mipvar$bin %in% mipbin,]$sample)

mrobin_sample2 <- unique(del_var[del_var$bin %in% mrobin,]$sample)
mipbin_sample2 <- unique(del_var[del_var$bin %in% mipbin,]$sample)
length(mrobin_sample2)
length(mipbin_sample2)
