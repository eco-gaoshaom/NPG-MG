library(ggplot2)
library(ggbreak)

pop_phyla <- read.table('../fig.3/3867pop.phyla',header = F)

phy_num <- as.data.frame(table(pop_phyla$V2))
phy_num <- phy_num[order(phy_num$Freq,decreasing = T),]
phy_num$phyla <- gsub("p__","",phy_num$Var1)

phy_num$phyla <- factor(phy_num$phyla,levels = rev(phy_num$phyla))
ggplot(phy_num)+
  geom_bar(aes(x=phyla,y=Freq),fill = "#3ca6cc",size = 0.5, color = '#3ca6cc',
           position="dodge", stat="identity",width = 0.5)+  
  labs(y="Phyla", x="Number of SGBs")+
  theme(panel.grid.major=element_line(colour=NA),panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        axis.line = element_line(colour = "black"),
        axis.title.x = element_text(size=12),axis.title.y = element_text(size=12,angle = 90),
        axis.text.x = element_text(hjust = 0.5,size=12,colour = 'black',angle = 0),
        axis.text.y=element_text(size=10,colour = 'black',angle =0))+
  theme(legend.position = 'top')+
  scale_y_continuous(limits = c(0,2500),breaks=seq(0,2500,500))+
  coord_flip(ylim = c(0,2500))+
  expand_limits(y=0)
  #scale_y_break(c(600,2000), space = 0.5, scales = 0.5, expand = c(0,0))
