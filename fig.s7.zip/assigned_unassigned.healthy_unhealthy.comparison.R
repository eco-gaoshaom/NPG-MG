otu_table <- read.delim('../fig.5/asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv_char <- read.table('../fig.5/asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('../fig.5/316sample.char',header = F)

asv_meanrel <- rowSums(otu_table)/sum(otu_table)
asv_meanpre <- apply(otu_table != 0,1,sum)
asv_df <- data.frame(asv_meanrel,asv_meanpre)
asv_df$asv_meanrel2 <- asv_df$asv_meanrel * 100
asv_df$asv_meanpre2 <- asv_df$asv_meanpre * 100/316
asv_df$phyla <- asv_char[rownames(otu_table),]$V3
asv_df$group <- ifelse(asv_df$phyla == "Unassigned","Unassigned","Assigned")

wilcox.test(asv_df$asv_meanrel2~asv_df$group)
wilcox.test(asv_df$asv_meanpre2~asv_df$group)

p1 <- ggplot(asv_df,aes(group,asv_meanrel2))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#3ca6cc","#bc587d"))+
  labs(x = "Group",y="Mean relative abundance (%)")+
  geom_signif(comparisons = list(c("Assigned","Unassigned")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  scale_y_continuous(limits = c(0,8),breaks = seq(0,8,2))+
  coord_cartesian(ylim= c(0,8))+
  expand_limits(y=0) 
p1

p2 <- ggplot(asv_df,aes(group,asv_meanpre2))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#3ca6cc","#bc587d"))+
  labs(x = "Group",y="Mean prevalence (%)")+
  geom_signif(comparisons = list(c("Assigned","Unassigned")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  scale_y_continuous(limits = c(0,80),breaks = seq(0,80,20))+
  coord_cartesian(ylim= c(0,80))+
  expand_limits(y=0) 
p2

#then compare the relative abundance/proportion of baci_a and pseu in healthy and unhealthy samples
otu_table <- read.delim('../fig.5/asv_dada2-table.otu2sample.subsampled10000',header = T,row.names = 1,check.names = F)
asv_char <- read.table('../fig.5/asv.char',header = F)
rownames(asv_char) <- asv_char$V1
sam_char <- read.table('../fig.5/316sample.char',header = F)

asv_both <- intersect(rownames(otu_table),asv_char$V1)
asv_char_sel <- asv_char[asv_both,]

otu_table_order <- otu_table[order(match(rownames(otu_table), asv_char_sel$V1)),]
otu_table_order$phyla <- asv_char_sel$V3
phyla_table <- aggregate(otu_table_order[,1:(ncol(otu_table_order)-1)],list(otu_table_order$phyla),sum)
rownames(phyla_table) <- phyla_table$Group.1
phyla_tablet <- as.data.frame(t(phyla_table[,-1]))
colnames(phyla_tablet) <- phyla_table$Group.1

phyla_tablet_order <- phyla_tablet[order(match(rownames(phyla_tablet), sam_char$V1)),]
phyla_tablet_order$group <- sam_char$V2
phyla_tablet_order <- phyla_tablet_order[rowSums(phyla_tablet_order[,1:26]) >= 10000,]
phyla_tablet_order[,1:26] <- phyla_tablet_order[,1:26]/rowSums(phyla_tablet_order[,1:26])

aggregate(phyla_tablet_order[,1:26],list(phyla_tablet_order$group),mean)
wilcox.test(phyla_tablet_order$p__Bacillota_A~phyla_tablet_order$group)
wilcox.test(phyla_tablet_order$p__Pseudomonadota~phyla_tablet_order$group)

p3 <- ggplot(phyla_tablet_order,aes(group,p__Bacillota_A))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#3ca6cc","#bc587d"))+
  labs(x = "Group",y="Relative abundance of Bacillota_A")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  scale_y_continuous(limits = c(0,1),breaks = seq(0,1,0.25))+
  coord_cartesian(ylim= c(0,1))+
  expand_limits(y=0) 
p3

p4 <- ggplot(phyla_tablet_order,aes(group,p__Pseudomonadota))+
  geom_jitter(aes(color = group),shape = 16,size=1.5,width = 0.15,alpha = 0.5)+
  #stat_boxplot(geom = "errorbar",width=0,aes(color = group),position = position_dodge(1),alpha = 0)+
  #geom_boxplot(aes(color = group),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#3ca6cc","#bc587d"))+
  labs(x = "Group",y="Relative abundance of Pseudomonadota")+
  geom_signif(comparisons = list(c("healthy","unhealthy")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'top')+
  scale_y_continuous(limits = c(0,1),breaks = seq(0,1,0.25))+
  coord_cartesian(ylim= c(0,1))+
  expand_limits(y=0) 
p4

library(gridExtra)
plots <- list(p1,p3,p2,p4)
grid.arrange(grobs = plots,ncol=2)
