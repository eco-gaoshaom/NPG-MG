char <- read.table('3867sgb.char',header = T)
char <- char[char$phyla != "p__Unclassified",]
rownames(char) <- char$bin

phy_char <- aggregate(char[,c(2:11,13:16)],list(char$phyla),mean)
phy_char[c(3,7,19,21),]
phy_char$length <- phy_char$length/1000

char_baci_a <- char[char$phyla == "p__Bacillota_A",]
char_pseu <- char[char$phyla == "p__Pseudomonadota",]

cor.test(phy_char$mro_mean,phy_char$aai_mean)
cor.test(phy_char$mip_mean,phy_char$length)

p1 <- ggplot(phy_char, aes(aai_mean,mro_mean)) +
  geom_point(color = "#999999",shape = 17,size = 3) + 
  geom_smooth(method = "lm", se = FALSE) +  
  labs(x = "Mean AAI (%)",y = "Mean MRO scores") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(36.5,42.5),breaks=seq(36.5,42.5,2))+
  scale_y_continuous(limits = c(0.36,0.6),breaks=seq(0.36,0.6,0.06))+
  coord_cartesian(xlim= c(36.5,42.5),ylim = c(0.36,0.6))+
  expand_limits(x=36.5,y=0.36)
p1
  
p2 <- ggplot(phy_char, aes(length,mip_mean)) +
  geom_point(color = "#999999",shape = 17,size = 3) +  
  geom_smooth(method = "lm", se = FALSE) +  
  labs(x = "Mean genome size (�� 103)",y = "Mean MIP scores") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 90,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(700,3500),breaks=seq(700,3500,700),labels = scales::comma)+
  scale_y_continuous(limits = c(0.8,3.2),breaks=seq(0.8,3.2,0.6))+
  coord_cartesian(xlim= c(700,3500),ylim = c(0.8,3.2))+
  expand_limits(x=700,y=0.8)
p2

library(gridExtra)
plots <- list(p1,p2)
grid.arrange(grobs = plots,ncol=1)
