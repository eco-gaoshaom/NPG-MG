library(tidyverse)
library(ggplot2)
library(ggdensity)

npgmg_trait <- read.delim("3867sgbs.trait.mapfile",header = F)
gtdb_trait <- read.delim("gtdb.bacia_pseu.trait.mapfile",header = F)

trait_map <- rbind(npgmg_trait,gtdb_trait)

trait_mat <- spread(trait_map,key=V1,value=V3)
trait_mat[is.na(trait_mat)] <- 0
row.names(trait_mat)<-trait_mat$V2
trait_mat <- trait_mat[,-1]
write.table(trait_mat,"npgmg_gtdb.trait_matrix",sep="\t")

trait_df <- as.data.frame(t(trait_mat))
trait_df$bin <- rownames(trait_df)

npgmg_phyla <- read.table('3867pop.phyla',header = F)
colnames(npgmg_phyla) <- c("bin","phyla")
gtdb_phyla <- read.table('gtdb.bacia_pseu.phyla',header = F)
colnames(gtdb_phyla) <- c("bin","phyla")

pop_phyla <- rbind(npgmg_phyla,gtdb_phyla)

trait_df <- left_join(trait_df,pop_phyla,by = "bin")
trait_df2 <- trait_df[trait_df$phyla %in% c("p__Bacillota_A","p__Pseudomonadota"),]
aggregate(trait_df2[,1:2],list(trait_df2$phyla),mean)

ggplot(trait_df2, aes(Anaerobic,Aerobic)) +
  geom_point(aes(color = phyla),shape = 16,size = 3) + 
  scale_color_manual(values = c("#bc587d","#3ca6cc"))+
  labs(x = "Confidence for anaerobic (%)",y = "Confidence for aerobic (%)") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 0,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(0,100),breaks=seq(0,100,25))+
  scale_y_continuous(limits = c(0,100),breaks=seq(0,100,25))+
  coord_cartesian(xlim= c(0,100),ylim = c(0,100))+
  expand_limits(x=0,y=0)

ggplot(trait_df2, aes(Anaerobic,Aerobic, fill = phyla)) +
  geom_hdr(xlim = c(0, 100), ylim = c(0, 100))+
  scale_fill_manual(values = c("#3ca6cc","#bc587d"))+
  stat_hdr(probs= c(0.99, 0.95, 0.8, 0.5,0.2),method = 'kde')+
  labs(x = "Confidence for anaerobic (%)",y = "Confidence for aerobic (%)") +
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,angle = 0,colour = 'black',hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),
        legend.text = element_text(size=4),
        legend.position = 'top')+
  scale_x_continuous(limits = c(0,100),breaks=seq(0,100,25))+
  scale_y_continuous(limits = c(0,100),breaks=seq(0,100,25))+
  coord_cartesian(xlim= c(0,100),ylim = c(0,100))+
  expand_limits(x=0,y=0)
