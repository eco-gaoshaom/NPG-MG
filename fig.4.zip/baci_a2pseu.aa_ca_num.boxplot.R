#compare the prop of baci_a and pseu in all samples
meta_data <- read.delim('../fig.2/841sample.metadata',header = T)
new_data <- meta_data[meta_data$Mapping_rate>=50 & meta_data$Richness > 10,]

mat <- read.delim("../fig.2/npgmg_841sample.cov",header = T,row.names = 1,check.names = F)
mat_new <- as.data.frame(mat)[,new_data$Sample_name]
mat_new <- mat_new[rowSums(mat_new) > 0,]

mat_new[mat_new != 0] <- 1

pop_phyla <- read.table('3867pop.phyla',header = F)
colnames(pop_phyla) <- c("bin","phyla")

pop_baci_a <- pop_phyla[pop_phyla$phyla == "p__Bacillota_A",]$bin
pop_pseu <- pop_phyla[pop_phyla$phyla == "p__Pseudomonadota",]$bin

site_prop <- matrix(0,368,2)

for (i in 1:184) {
  print(i)
  site_mag <- c(rownames(mat_new)[mat_new[,i]> 0])
  bacia_prop <- length(intersect(site_mag,pop_baci_a))/length(site_mag)
  pseu_prop <- length(intersect(site_mag,pop_pseu))/length(site_mag)
  site_prop[i,1] <- bacia_prop
  site_prop[184+i,1] <- pseu_prop
}
site_prop <- as.data.frame(site_prop)
site_prop[,2] <- c(replicate(184,"Bacillota_A"),replicate(184,"Pseudomonadota"))
colnames(site_prop) <- c("prop","phyla")

p1 <- ggplot(site_prop,aes(phyla,prop))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = phyla),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = phyla),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Phyla",y="Proportion in samples")+
  geom_signif(comparisons = list(c("Bacillota_A","Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,1),breaks = seq(0,1,0.25))+
  coord_cartesian(ylim= c(0,1))+
  expand_limits(y=0)  
p1


#compare the aa and ca number in bacia and pseu
char <- read.table('3867sgb.char',header = T)
char <- char[char$phyla != "p__Unclassified",]
rownames(char) <- char$bin

char_baci_a <- char[char$phyla == "p__Bacillota_A",]
char_pseu <- char[char$phyla == "p__Pseudomonadota",]

aa_ca_df <- rbind(char_baci_a,char_pseu)
wilcox.test(aa_ca_df$aanum~aa_ca_df$phyla)
wilcox.test(aa_ca_df$canum~aa_ca_df$phyla)

p2 <- ggplot(aa_ca_df,aes(phyla,aanum))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = phyla),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = phyla),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Phyla",y="Number of amino acids")+
  geom_signif(comparisons = list(c("p__Bacillota_A","p__Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,21),breaks = seq(0,21,7))+
  coord_cartesian(ylim= c(0,21))+
  expand_limits(y=0)  
p2

p3 <- ggplot(aa_ca_df,aes(phyla,canum))+
  #geom_jitter(shape = 16,size=1.5,width = 0.15,alpha = 0.5,color = "#c8c8c8")+
  stat_boxplot(geom = "errorbar",width=0,aes(color = phyla),position = position_dodge(1),alpha = 0)+
  geom_boxplot(aes(color = phyla),width=0.3,position = position_dodge(1),outlier.shape = NA,fill = "#FFFFFF",alpha = 0)+
  scale_color_manual(values=c("#bc587d","#3ca6cc"))+
  labs(x = "Phyla",y="Number of carbon sources")+
  geom_signif(comparisons = list(c("p__Bacillota_A","p__Pseudomonadota")),
              map_signif_level = F, 
              textsize = 4, 
              test = "wilcox.test")+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'none')+
  scale_y_continuous(limits = c(0,60),breaks = seq(0,60,20))+
  coord_cartesian(ylim= c(0,60))+
  expand_limits(y=0)  
p3

library(gridExtra)
plots <- list(p1,p2,p3)
grid.arrange(grobs = plots,ncol=1)
