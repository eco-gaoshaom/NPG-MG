gtdb_source <- read.delim('bac120_metadata_r220.cut.re',header = F)
colnames(gtdb_source) <- c("name","com","con","bp","source","phyla")

baci_a_so <- as.data.frame(table(gtdb_source[gtdb_source$phyla == "p__Bacillota_A",]$source))
pseu_so <- as.data.frame(table(gtdb_source[gtdb_source$phyla == "p__Pseudomonadota",]$source))

baci_a_so <- baci_a_so[order(baci_a_so$Freq,decreasing = T),]
pseu_so <- pseu_so[order(pseu_so$Freq,decreasing = T),]

host_char <- c("fece","stool","feca","face","faec","gut","intestin","blood","sputum","urine","lung","clinic","recta",
               "fish","animal","human","rumen","plant","leaf","root","cattle","vagin","vacu","tissue","manure",
               "anal","anus","skin","sheep","rabbit","meat","patient","oral","liver","lung","insect","infant",
               "ileal","honey","health","horse","chicken","fish","child","cecum","cat","saliva","wound","tissue",
               "bovine","bile","host","caecum","tumor","umbilicus","juvenile","young","adult","toe","urine","male","female"
)
library(dplyr)  
library(stringr)
baci_a_so$Var1 <- tolower(baci_a_so$Var1)
pseu_so$Var1 <- tolower(pseu_so$Var1)


baci_a_so$MatchFound <- sapply(baci_a_so$Var1, function(x) any(grepl(paste(host_char, collapse = "|"), x)))
baci_a_so_host <- baci_a_so[baci_a_so$MatchFound, ]  
baci_a_so_host <- baci_a_so_host %>%  
  group_by(CombinedSource = "CommonSource") %>%  # ʹ��һ��ͨ�õĺϲ���ǩ  
  summarise(Value = sum(Freq), .groups = 'drop')

pseu_so$MatchFound <- sapply(pseu_so$Var1, function(x) any(grepl(paste(host_char, collapse = "|"), x)))
pseu_so_host <- pseu_so[pseu_so$MatchFound, ]  
pseu_so_host <- pseu_so_host %>%  
  group_by(CombinedSource = "CommonSource") %>%  # ʹ��һ��ͨ�õĺϲ���ǩ  
  summarise(Value = sum(Freq), .groups = 'drop')

baci_a_host_prop <- baci_a_so_host$Value/(sum(baci_a_so$Freq)-sum(baci_a_so[baci_a_so$Var1 == "none",]$Freq))
pseu_host_prop <- pseu_so_host$Value/(sum(pseu_so$Freq)-sum(pseu_so[pseu_so$Var1 == "none",]$Freq))

prop <- c(baci_a_host_prop,pseu_host_prop,
          1-baci_a_host_prop,1-pseu_host_prop)
group <- c("Host-associated","Host-associated","Others","Others")
phyla <- c("Bacillota_A","Pseudomonadota","Bacillota_A","Pseudomonadota")
prop_host_df <- data.frame(prop,group,phyla)

prop_host_df$group <- factor(prop_host_df$group,levels = c(unique(group)))
prop_host_df2 <- prop_host_df[prop_host_df$phyla %in% c("Bacillota_A","Pseudomonadota"),]

p1 <- ggplot(prop_host_df2,aes(phyla,prop,fill=group))+
  geom_bar(stat = 'identity',position = 'stack',width =0.25)+
  scale_fill_manual(values = c("#bc587d","#3ca6cc"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
        axis.title.x = element_text(size=15),axis.title.y = element_text(size=15),
        axis.text.x = element_text(hjust = 0.5,angle = 0,size=12,colour = 'black'),
        axis.text.y=element_text(size=12,colour = 'black',angle = 90,hjust = 0.5),panel.border = element_blank(),
        axis.line = element_line(linewidth =0.5,colour="black"),legend.text = element_text(size=8),
        legend.position = 'right')+
  labs(x="Phyla",y="Proportion")+
  #scale_x_continuous(limits = c(0.45,0.6),breaks=seq(0.45,0.6,0.05))+
  scale_y_continuous(limits = c(0,1),breaks=seq(0,1,0.25))+
  expand_limits(y=0)
p1
